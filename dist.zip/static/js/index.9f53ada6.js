(()=>{"use strict";var e={1600:function(e,t,i){var r,n=i(6773),s=i(1699),a=i(8511),l=i(4903),o=i(5446);let d=o.Z.div`
  margin: 2rem auto 3rem;
  max-width: 700px;
  width: 100%;
  
  /* 添加入场动画 */
  animation: searchFadeIn 0.8s ease-out 0.3s both;
  
  @keyframes searchFadeIn {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }

  @media (max-width: 768px) {
    margin: 1.5rem auto 2.5rem;
  }
`,c=o.Z.form`
  display: flex;
  gap: 12px;
  width: 100%;
  align-items: stretch;

  @media (max-width: 768px) {
    flex-direction: column;
    gap: 12px;
  }
`,h=o.Z.input`
  flex: 1;
  padding: 15px 24px;
  font-size: 16px;
  border: 2px solid ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.2)":"rgba(0, 0, 0, 0.1)"};
  border-radius: 30px;
  outline: none;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  -webkit-appearance: none;
  appearance: none;
  background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.1)":"rgba(255, 255, 255, 0.9)"};
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#333333"};
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 
    0 4px 12px rgba(0, 0, 0, 0.05),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
  min-width: 0; /* 防止flex子元素收缩问题 */

  &:focus {
    border-color: #4a90e2;
    background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.15)":"white"};
    box-shadow: 
      0 0 0 4px rgba(74, 144, 226, 0.15),
      0 8px 24px rgba(74, 144, 226, 0.1),
      inset 0 1px 0 rgba(255, 255, 255, 0.2);
    transform: translateY(-2px);
  }

  &::placeholder {
    color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.6)":"rgba(0, 0, 0, 0.4)"};
  }

  @media (max-width: 768px) {
    padding: 14px 20px;
    font-size: 16px; /* 防止 iOS 缩放 */
    border-radius: 25px;
  }
  
  @media (max-width: 480px) {
    padding: 12px 18px;
    border-radius: 20px;
  }
`,x=o.Z.div`
  position: relative;
  display: inline-block;
  min-width: 140px;
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#666666"};
  
  /* 箭头指示器 */
  &::after {
    content: '';
    position: absolute;
    top: 50%;
    right: 16px;
    transform: translateY(-50%);
    width: 0;
    height: 0;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid currentColor;
    pointer-events: none;
    transition: all 0.2s ease;
    z-index: 1;
  }
  
  &:hover {
    color: #4a90e2;
  }
  
  @media (max-width: 768px) {
    min-width: 120px;
    
    &::after {
      right: 14px;
      border-left-width: 4px;
      border-right-width: 4px;
      border-top-width: 5px;
    }
  }
  
  @media (max-width: 480px) {
    min-width: 110px;
    
    &::after {
      right: 12px;
    }
  }
`,p=o.Z.select`
  width: 100%;
  padding: 15px 45px 15px 20px;
  border: 2px solid ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.2)":"rgba(0, 0, 0, 0.1)"};
  border-radius: 30px;
  background-color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.1)":"rgba(255, 255, 255, 0.9)"};
  cursor: pointer;
  font-size: 0.9rem;
  font-weight: 500;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#333333"};
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
  box-shadow: 
    0 4px 12px rgba(0, 0, 0, 0.05),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);

  &:hover {
    border-color: #4a90e2;
    background-color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.15)":"white"};
    transform: translateY(-1px);
  }

  &:focus {
    border-color: #4a90e2;
    background-color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.15)":"white"};
    box-shadow: 
      0 0 0 4px rgba(74, 144, 226, 0.15),
      0 8px 24px rgba(74, 144, 226, 0.1),
      inset 0 1px 0 rgba(255, 255, 255, 0.2);
    outline: none;
  }

  @media (max-width: 768px) {
    padding: 14px 40px 14px 18px;
    font-size: 0.875rem;
    border-radius: 25px;
  }
  
  @media (max-width: 480px) {
    padding: 12px 36px 12px 16px;
    font-size: 0.8rem;
    border-radius: 20px;
  }
`,g=o.Z.button`
  padding: 15px 32px;
  border: none;
  border-radius: 30px;
  background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
  color: white;
  font-weight: 600;
  font-size: 0.95rem;
  cursor: pointer;
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  white-space: nowrap;
  box-shadow: 
    0 4px 12px rgba(74, 144, 226, 0.3),
    0 2px 6px rgba(0, 0, 0, 0.1);
  position: relative;
  overflow: hidden;
  min-width: 100px;
  
  /* 添加光泽效果 */
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      90deg,
      transparent,
      rgba(255, 255, 255, 0.2),
      transparent
    );
    transition: left 0.5s;
  }

  &:hover {
    background: linear-gradient(135deg, #357abd 0%, #2868a3 100%);
    transform: translateY(-2px);
    box-shadow: 
      0 8px 24px rgba(74, 144, 226, 0.4),
      0 4px 12px rgba(0, 0, 0, 0.15);
    
    &::before {
      left: 100%;
    }
  }
  
  &:active {
    transform: translateY(0);
  }

  @media (max-width: 768px) {
    padding: 14px 28px;
    font-size: 0.9rem;
    border-radius: 25px;
    min-width: 90px;
  }
  
  @media (max-width: 480px) {
    padding: 12px 24px;
    font-size: 0.85rem;
    border-radius: 20px;
    min-width: 80px;
  }
`,m=e=>{let{searchEngines:t}=e,[i,r]=(0,s.useState)(""),[a,l]=(0,s.useState)(t[0].id);return(0,n.jsx)(d,{children:(0,n.jsxs)(c,{onSubmit:e=>{if(e.preventDefault(),!i.trim())return;let r=t.find(e=>e.id===a);r&&window.open(r.url+encodeURIComponent(i),"_blank")},children:[(0,n.jsx)(h,{type:"text",value:i,onChange:e=>r(e.target.value),placeholder:"输入搜索内容..."}),(0,n.jsx)(x,{children:(0,n.jsx)(p,{value:a,onChange:e=>l(e.target.value),children:t.map(e=>(0,n.jsxs)("option",{value:e.id,children:[e.icon," ",e.name]},e.id))})}),(0,n.jsx)(g,{type:"submit",children:"搜索"})]})})},u=o.Z.section`
  margin: 2.5rem 0;
  padding: 0;
  background: transparent;
  border-radius: 16px;
  
  /* 添加入场动画 */
  animation: categoryFadeIn 0.8s ease-out both;
  
  @keyframes categoryFadeIn {
    from {
      opacity: 0;
      transform: translateY(30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  /* 逐个延迟动画 */
  &:nth-of-type(1) { animation-delay: 0.5s; }
  &:nth-of-type(2) { animation-delay: 0.6s; }
  &:nth-of-type(3) { animation-delay: 0.7s; }
  &:nth-of-type(4) { animation-delay: 0.8s; }
  &:nth-of-type(n+5) { animation-delay: 0.9s; }
`,f=o.Z.h2`
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#2c3e50"};
  font-size: 1.4rem;
  font-weight: 700;
  margin-bottom: 1.5rem;
  padding: 0.75rem 1rem;
  background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.08)":"rgba(255, 255, 255, 0.6)"};
  border-radius: 12px;
  border-left: 4px solid #4a90e2;
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  box-shadow: 
    0 2px 8px rgba(0, 0, 0, 0.05),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
  position: relative;
  
  /* 添加微妙的反光效果 */
  &::after {
    content: '';
    position: absolute;
    top: 0;
    right: 0;
    width: 60px;
    height: 100%;
    background: linear-gradient(
      90deg,
      transparent,
      rgba(255, 255, 255, 0.1)
    );
    border-radius: 0 12px 12px 0;
  }
`,j=o.Z.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 1.25rem;
  margin-top: 0.5rem;
  padding: 0 1rem;
  
  @media (max-width: 768px) {
    grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
    gap: 1rem;
    padding: 0 0.5rem;
  }
  
  @media (max-width: 480px) {
    grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
    gap: 0.75rem;
    padding: 0;
  }
`,y=o.Z.a`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 1.5rem 1rem;
  background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.08)":"rgba(255, 255, 255, 0.8)"};
  border-radius: 16px;
  text-decoration: none;
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#333333"};
  transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border: 1px solid ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.1)":"rgba(255, 255, 255, 0.3)"};
  box-shadow: 
    0 4px 12px rgba(0, 0, 0, 0.05),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
  position: relative;
  overflow: hidden;
  min-height: 120px;
  
  /* 添加微妙的背景效果 */
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(
      135deg,
      transparent 0%,
      rgba(74, 144, 226, 0.02) 50%,
      transparent 100%
    );
    opacity: 0;
    transition: opacity 0.3s;
  }

  &:hover {
    transform: translateY(-4px) scale(1.02);
    box-shadow: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"0 12px 32px rgba(255, 255, 255, 0.1), 0 4px 16px rgba(0, 0, 0, 0.1)":"0 12px 32px rgba(74, 144, 226, 0.15), 0 4px 16px rgba(0, 0, 0, 0.1)"};
    background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.12)":"rgba(255, 255, 255, 0.95)"};
    border-color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.2)":"rgba(74, 144, 226, 0.2)"};
    color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#2c3e50"};
    
    &::before {
      opacity: 1;
    }
    
    /* 悬停时的图标和文字效果 */
    span:first-of-type {
      transform: scale(1.1);
      filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.15));
    }
    
    span:last-of-type {
      color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#2c3e50"};
      font-weight: 600;
    }
  }
  
  &:active {
    transform: translateY(-2px) scale(1.01);
  }
`,b=o.Z.span`
  font-size: 2.5rem;
  margin-bottom: 0.75rem;
  display: block;
  filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.1));
  transition: all 0.3s ease;
`,Z=o.Z.span`
  font-size: 0.875rem;
  font-weight: 500;
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.9)":"#555555"};
  text-align: center;
  line-height: 1.4;
  transition: all 0.3s ease;
`,v=e=>{let{categories:t}=e;return(0,n.jsx)(n.Fragment,{children:t.sort((e,t)=>e.id-t.id).map(e=>(0,n.jsxs)(u,{children:[(0,n.jsx)(f,{children:e.name}),(0,n.jsx)(j,{children:e.links.map(e=>(0,n.jsxs)(y,{href:e.url,target:"_blank",rel:"noopener noreferrer",children:[(0,n.jsx)(b,{children:e.icon}),(0,n.jsx)(Z,{children:e.name})]},e.id))})]},e.id))})},S=o.Z.div`
  min-height: 100vh;
  position: relative;
  padding: 2rem;

  &::before {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: ${e=>e.theme.backgroundImage};
    background-size: 400% 400%;
    animation: gradient 15s ease infinite;
    z-index: -2;
  }

  @keyframes gradient {
    0% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
    100% {
      background-position: 0% 50%;
    }
  }

  &::after {
    content: '';
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"0.1":"0.3"});
    backdrop-filter: blur(${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"5px":"8px"});
    -webkit-backdrop-filter: blur(${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"5px":"8px"});
    z-index: -1;
  }

  @media (max-width: 768px) {
    padding: 1rem;
  }
`;var k=i(3438);class w{getConfig(){return this.config}getDefaultTheme(){return this.config.default}getPresets(){return this.config.presets}setDefaultTheme(e){this.config.default=e,this.saveToStorage()}addPreset(e){if(this.config.presets.some(t=>t.id===e.id))throw Error(`Theme with id ${e.id} already exists`);this.config.presets.push(e),this.saveToStorage()}updatePreset(e){let t=this.config.presets.findIndex(t=>t.id===e.id);if(-1===t)throw Error(`Theme with id ${e.id} not found`);this.config.presets[t]=e,this.saveToStorage()}deletePreset(e){let t=this.config.presets.findIndex(t=>t.id===e);if(-1===t)throw Error(`Theme with id ${e} not found`);this.config.presets.splice(t,1),this.saveToStorage()}findThemeById(e){return this.config.default.id===e?this.config.default:this.config.presets.find(t=>t.id===e)}loadFromStorage(){try{let e=localStorage.getItem(w.STORAGE_KEY);return e?JSON.parse(e):null}catch(e){return console.error("Failed to load theme config from storage:",e),null}}saveToStorage(){try{localStorage.setItem(w.STORAGE_KEY,JSON.stringify(this.config))}catch(e){console.error("Failed to save theme config to storage:",e)}}clearStorage(){localStorage.removeItem(w.STORAGE_KEY)}resetToDefault(e){this.config={...e},this.saveToStorage()}constructor(e){(0,k._)(this,"config",void 0),this.config=this.loadFromStorage()||e||{default:{id:"default",name:"默认主题",backgroundImage:"linear-gradient(120deg, #f6d365 0%, #fda085 100%)",blur:"10px",opacity:.95},presets:[]},this.saveToStorage()}}(0,k._)(w,"STORAGE_KEY","turnip-theme-config");let I={default:{id:"morning",name:"晨光蓝",backgroundImage:"linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%)",blur:"10px",opacity:.95},presets:[{id:"purple",name:"渐变紫",backgroundImage:"linear-gradient(to right, #6a11cb 0%, #2575fc 100%)",blur:"10px",opacity:.95},{id:"morning",name:"晨光蓝",backgroundImage:"linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%)",blur:"10px",opacity:.95},{id:"night",name:"夜空",backgroundImage:"linear-gradient(to right, #243949 0%, #517fa4 100%)",blur:"10px",opacity:.92}]},C=new w(I),E=[{id:0,name:"影音视频",links:[{id:1,name:"爱奇艺",url:"https://www.iqiyi.com/",icon:"\uD83C\uDFAC"},{id:2,name:"优酷",url:"https://www.youku.com/",icon:"\uD83C\uDFAC"},{id:3,name:"腾讯视频",url:"https://v.qq.com/",icon:"\uD83D\uDC27"},{id:4,name:"哔哩哔哩",url:"https://www.bilibili.com/",icon:"bilibili"},{id:5,name:"抖音",url:"https://www.douyin.com/",icon:"\uD83C\uDFB5"}]},{id:-1,name:"Turnip",links:[{id:1,name:"Turnip博客",url:"https://turnip1202.github.io/my-blog-astro/",icon:"\uD83E\uDD55"},{id:2,name:"GitHub",url:"https://github.com/Turnip1202",icon:"⭐"},{id:3,name:"稀土掘金",url:"https://juejin.cn/user/1684912023022440",icon:"\uD83D\uDD28"},{id:4,name:"哔哩哔哩",url:"https://b23.tv/zpySzz9",icon:"\uD83C\uDFAE"},{id:5,name:"抖音",url:"https://v.douyin.com/if78aSq9/",icon:"\uD83C\uDFAC"},{id:6,name:"react-study",url:"https://turnip1202.github.io/react-study",icon:"\uD83D\uDCCB"}]},{id:2,name:"开发工具",links:[{id:1,name:"GitHub",url:"https://github.com",icon:"\uD83D\uDC19"},{id:2,name:"VS Code",url:"https://code.visualstudio.com",icon:"\uD83D\uDCDD"},{id:3,name:"Stack Overflow",url:"https://stackoverflow.com",icon:"\uD83D\uDCA1"}]},{id:3,name:"学习资源",links:[{id:4,name:"TypeScript",url:"https://www.typescriptlang.org",icon:"\uD83D\uDCD8"},{id:5,name:"React Docs",url:"https://reactjs.org",icon:"⚛️"},{id:6,name:"掘金",url:"https://juejin.cn",icon:"\uD83C\uDFAF"}]}],P=[{id:"bing",name:"Bing",url:"https://www.bing.com/search?q=",icon:"\uD83D\uDD0E"},{id:"google",name:"Google",url:"https://www.google.com/search?q=",icon:"\uD83D\uDD0D"},{id:"baidu",name:"百度",url:"https://www.baidu.com/s?wd=",icon:"\uD83D\uDD0D"}],T=new class{getFromStorage(e){try{let t=localStorage.getItem(e);return t?JSON.parse(t):null}catch(e){return console.error(`Error reading from localStorage: ${e}`),null}}saveToStorage(e,t){try{localStorage.setItem(e,JSON.stringify(t))}catch(e){console.error(`Error saving to localStorage: ${e}`)}}getCategoryById(e){return this.categories.find(t=>t.id===e)}addCategory(e){let t={id:this.categories.length?Math.max(...this.categories.map(e=>e.id))+1:0,name:e,links:[]};return this.categories.push(t),this.saveToStorage(this.CATEGORIES_KEY,this.categories),t}updateCategory(e,t){let i=this.getCategoryById(e);return!!i&&(i.name=t,this.saveToStorage(this.CATEGORIES_KEY,this.categories),!0)}deleteCategory(e){let t=this.categories.findIndex(t=>t.id===e);return -1!==t&&(this.categories.splice(t,1),this.saveToStorage(this.CATEGORIES_KEY,this.categories),!0)}addLink(e,t,i,r){let n=this.getCategoryById(e);if(!n)return!1;let s=n.links.length?Math.max(...n.links.map(e=>e.id))+1:1;return n.links.push({id:s,name:t,url:i,icon:r}),this.saveToStorage(this.CATEGORIES_KEY,this.categories),!0}updateLink(e,t,i){let r=this.getCategoryById(e);if(!r)return!1;let n=r.links.find(e=>e.id===t);return!!n&&(Object.assign(n,i),this.saveToStorage(this.CATEGORIES_KEY,this.categories),!0)}deleteLink(e,t){let i=this.getCategoryById(e);if(!i)return!1;let r=i.links.findIndex(e=>e.id===t);return -1!==r&&(i.links.splice(r,1),this.saveToStorage(this.CATEGORIES_KEY,this.categories),!0)}getSearchEngineById(e){return this.engines.find(t=>t.id===e)}addSearchEngine(e,t,i,r){return!this.getSearchEngineById(e)&&(this.engines.push({id:e,name:t,url:i,icon:r}),this.saveToStorage(this.ENGINES_KEY,this.engines),!0)}updateSearchEngine(e,t){let i=this.getSearchEngineById(e);return!!i&&(Object.assign(i,t),this.saveToStorage(this.ENGINES_KEY,this.engines),!0)}deleteSearchEngine(e){let t=this.engines.findIndex(t=>t.id===e);return -1!==t&&(this.engines.splice(t,1),this.saveToStorage(this.ENGINES_KEY,this.engines),!0)}getAllCategories(){return[...this.categories]}getAllSearchEngines(){return[...this.engines]}clearStorage(){localStorage.removeItem(this.CATEGORIES_KEY),localStorage.removeItem(this.ENGINES_KEY)}resetToDefault(e,t){this.categories=[...e],this.engines=[...t],this.saveToStorage(this.CATEGORIES_KEY,this.categories),this.saveToStorage(this.ENGINES_KEY,this.engines)}constructor(e,t){(0,k._)(this,"categories",void 0),(0,k._)(this,"engines",void 0),(0,k._)(this,"CATEGORIES_KEY","turnip_link_categories"),(0,k._)(this,"ENGINES_KEY","turnip_search_engines");let i=this.getFromStorage(this.CATEGORIES_KEY),r=this.getFromStorage(this.ENGINES_KEY);this.categories=i||[...e],this.categories.sort((e,t)=>e.id-t.id),this.categories.forEach(e=>{e.links.sort((e,t)=>e.id-t.id)}),this.engines=r||[...t],i||this.saveToStorage(this.CATEGORIES_KEY,this.categories),r||this.saveToStorage(this.ENGINES_KEY,this.engines)}}(E,P),A={title:"Turnip起始页",copyright:{text:`\xa9 ${new Date().getFullYear()} Turnip1202. All rights reserved.`}},D=new class{getFromStorage(){try{let e=localStorage.getItem(this.STORAGE_KEY);return e?JSON.parse(e):null}catch(e){return console.error(`读取本地存储出错: ${e}`),null}}applyConfigToDOM(){this.config.title&&(document.title=this.config.title),this.config.favicon&&this.updateFavicon(this.config.favicon)}saveToStorage(){try{localStorage.setItem(this.STORAGE_KEY,JSON.stringify(this.config))}catch(e){console.error(`保存到本地存储出错: ${e}`)}}getConfig(){return{...this.config}}updateTitle(e){this.config.title=e,this.saveToStorage(),document.title=e}updateCopyright(e){this.config.copyright.text=e,this.saveToStorage()}addConfigItem(e,t){this.config[e]=t,this.saveToStorage(),"favicon"===e&&t&&this.updateFavicon(t)}updateFavicon(e){if(!e)return;document.querySelectorAll('link[rel*="icon"]').forEach(e=>e.remove());let t=document.createElement("link");t.rel="shortcut icon",t.type="image/x-icon",t.href=e,document.head.appendChild(t);let i=document.createElement("link");i.rel="icon",i.type="image/x-icon",i.href=e,document.head.appendChild(i)}deleteConfigItem(e){return"title"!==e&&"copyright"!==e&&e in this.config&&(delete this.config[e],this.saveToStorage(),!0)}resetToDefault(e){this.config={...e},this.saveToStorage()}clearStorage(){localStorage.removeItem(this.STORAGE_KEY)}constructor(e){(0,k._)(this,"config",void 0),(0,k._)(this,"STORAGE_KEY","turnip_site_config");let t=this.getFromStorage();this.config=t||{...e},t||this.saveToStorage(),this.applyConfigToDOM()}}(A),_=new class{loadFromStorage(){try{let e=localStorage.getItem(this.STORAGE_KEY);if(e){let t=JSON.parse(e);return{versions:t.versions||[],currentVersionId:t.currentVersionId,maxVersions:t.maxVersions||this.MAX_VERSIONS}}}catch(e){console.warn("Failed to load version data:",e)}return{versions:[],maxVersions:this.MAX_VERSIONS}}saveToStorage(){try{localStorage.setItem(this.STORAGE_KEY,JSON.stringify(this.versionData))}catch(e){console.error("Failed to save version data:",e)}}generateId(){return`v_${Date.now()}_${Math.random().toString(36).substr(2,9)}`}getCurrentConfigData(){return{site:D.getConfig(),theme:{default:C.getDefaultTheme(),presets:C.getPresets()},links:{categories:T.getAllCategories(),searchEngines:T.getAllSearchEngines()}}}createVersion(e){let t={id:this.generateId(),name:e.name,description:e.description,timestamp:Date.now(),data:this.getCurrentConfigData(),tags:e.tags||[],isAutoSaved:e.isAutoSaved||!1};return this.versionData.versions.unshift(t),this.versionData.versions.length>this.versionData.maxVersions&&(this.versionData.versions=this.versionData.versions.slice(0,this.versionData.maxVersions)),this.versionData.currentVersionId=t.id,this.saveToStorage(),t}getAllVersions(){return[...this.versionData.versions]}getVersion(e){return this.versionData.versions.find(t=>t.id===e)||null}deleteVersion(e){let t=this.versionData.versions.findIndex(t=>t.id===e);return -1!==t&&(this.versionData.versions.splice(t,1),this.versionData.currentVersionId===e&&(this.versionData.currentVersionId=void 0),this.saveToStorage(),!0)}restoreVersion(e){let t=this.getVersion(e);if(!t)return!1;try{if(t.data.site){var i;t.data.site.title&&D.updateTitle(t.data.site.title),(null===(i=t.data.site.copyright)||void 0===i?void 0:i.text)&&D.updateCopyright(t.data.site.copyright.text),Object.keys(t.data.site).forEach(e=>{"title"!==e&&"copyright"!==e&&D.addConfigItem(e,t.data.site[e])})}return t.data.theme&&console.log("主题配置恢复功能待实现"),t.data.links&&t.data.links.categories&&(T.getAllCategories().forEach(e=>T.deleteCategory(e.id)),t.data.links.categories.forEach(e=>{let t=T.addCategory(e.name);e.links&&e.links.forEach(e=>{T.addLink(t.id,e.name,e.url,e.icon)})})),this.versionData.currentVersionId=e,this.saveToStorage(),!0}catch(e){return console.error("Failed to restore version:",e),!1}}compareVersions(e,t){let i=this.getVersion(e),r=this.getVersion(t);if(!i||!r)return null;let n={},s=0,a=this.compareObjects(i.data.site,r.data.site);a.length>0&&(n.site=a,s+=a.length);let l=this.compareObjects(i.data.theme,r.data.theme);l.length>0&&(n.theme=l,s+=l.length);let o=this.compareObjects(i.data.links,r.data.links);return o.length>0&&(n.links=o,s+=o.length),{changes:n,summary:`共发现 ${s} 处变更`}}compareObjects(e,t){let i=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"",r=[];return new Set([...Object.keys(e||{}),...Object.keys(t||{})]).forEach(n=>{let s=i?`${i}.${n}`:n,a=null==e?void 0:e[n],l=null==t?void 0:t[n];"object"==typeof a&&"object"==typeof l&&a&&l?r.push(...this.compareObjects(a,l,s)):JSON.stringify(a)!==JSON.stringify(l)&&r.push(`${s}: ${JSON.stringify(a)} → ${JSON.stringify(l)}`)}),r}autoSave(){return this.createVersion({name:`自动保存_${new Date().toLocaleString("zh-CN")}`,description:"系统自动保存的版本",isAutoSaved:!0})}cleanupAutoSaves(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:5,t=this.versionData.versions.filter(e=>e.isAutoSaved).slice(e),i=0;return t.forEach(e=>{this.deleteVersion(e.id)&&i++}),i}getCurrentVersionId(){return this.versionData.currentVersionId}exportVersions(){return JSON.stringify(this.versionData,null,2)}importVersions(e){try{let t=JSON.parse(e);if(t.versions&&Array.isArray(t.versions))return this.versionData={versions:t.versions,currentVersionId:t.currentVersionId,maxVersions:t.maxVersions||this.MAX_VERSIONS},this.saveToStorage(),!0}catch(e){console.error("Failed to import versions:",e)}return!1}constructor(){(0,k._)(this,"STORAGE_KEY","turnip_config_versions"),(0,k._)(this,"MAX_VERSIONS",20),(0,k._)(this,"versionData",void 0),this.versionData=this.loadFromStorage()}},N=class{static getProjectVersion(){return"1.0.0"}static getConfigVersionInfo(){try{let e=_.getAllVersions(),t=_.getCurrentVersionId(),i="默认配置";if(t&&e.length>0){let r=e.find(e=>e.id===t);i=r?r.name:"未知版本"}return{total:e.length,current:t||null,currentName:i}}catch(e){return{total:0,current:null,currentName:"获取失败"}}}static getVersionStatusText(){let e=this.getConfigVersionInfo();return 0===e.total?"无版本记录":`${e.currentName} (共${e.total}个版本)`}static getSystemSummary(){let e=this.getConfigVersionInfo();return{projectVersion:this.getProjectVersion(),configVersions:e.total,currentConfigVersion:e.currentName,lastModified:new Date().toISOString()}}},z=e=>JSON.parse(localStorage.getItem(e)||"[]"),O=o.Z.div`
  position: fixed;
  bottom: 24px;
  right: 24px;
  background: rgba(255, 255, 255, 0.9);
  padding: 12px;
  border-radius: 16px;
  box-shadow: 
    0 8px 32px rgba(0, 0, 0, 0.15),
    0 2px 16px rgba(0, 0, 0, 0.05);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  display: ${e=>e.isVisible?"flex":"none"};
  flex-direction: column;
  gap: 8px;
  min-width: auto;
  z-index: 1000;
  transition: all 0.3s ease;
  
  @media (max-width: 768px) {
    bottom: 20px;
    right: 20px;
    padding: 10px;
    border-radius: 14px;
  }
`,$=o.Z.button`
  position: fixed;
  bottom: 24px;
  right: 80px;
  width: 48px;
  height: 48px;
  border: none;
  border-radius: 50%;
  background: linear-gradient(135deg, #4a90e2 0%, #357abd 100%);
  color: white;
  cursor: pointer;
  transition: all 0.3s ease;
  font-size: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 16px rgba(74, 144, 226, 0.3);
  z-index: 1001;
  
  &:hover {
    transform: translateY(-3px) scale(1.05);
    box-shadow: 0 8px 24px rgba(74, 144, 226, 0.4);
  }
  
  @media (max-width: 768px) {
    bottom: 20px;
    right: 80px;
    width: 44px;
    height: 44px;
    font-size: 18px;
  }
`,L=o.Z.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 4px;
`,V=o.Z.div`
  display: flex;
  flex-direction: column;
  gap: 8px;
  width: 100%;
  margin-bottom: 4px;
`,F=o.Z.button`
  padding: 8px;
  width: 44px;
  height: 44px;
  border: 2px solid ${e=>e.isSelected?"#4a90e2":"transparent"};
  border-radius: 12px;
  background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#333":e.theme.backgroundImage};
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  align-items: center;
  justify-content: center;
  position: relative;
  overflow: hidden;
  
  /* 添加反光效果 */
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
      90deg,
      transparent,
      rgba(255, 255, 255, 0.3),
      transparent
    );
    transition: left 0.5s;
  }
  
  &:hover {
    transform: scale(1.08);
    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
    border-color: ${e=>e.isSelected?"#357abd":"rgba(74, 144, 226, 0.5)"};
    
    &::before {
      left: 100%;
    }
  }
  
  &:active {
    transform: scale(1.02);
  }
`,R=o.Z.button`
  padding: 10px;
  width: 44px;
  height: 44px;
  border: none;
  border-radius: 12px;
  background: ${e=>e.active?"linear-gradient(135deg, #4a90e2 0%, #357abd 100%)":"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.1)":"rgba(0, 0, 0, 0.05)"};
  color: ${e=>e.active?"white":"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#fff":"#666"};
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  font-size: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
  box-shadow: ${e=>e.active?"0 4px 12px rgba(74, 144, 226, 0.3), inset 0 1px 0 rgba(255, 255, 255, 0.2)":"0 2px 8px rgba(0, 0, 0, 0.05)"};
  position: relative;
  overflow: hidden;
  
  /* 添加波纹效果 */
  &::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    width: 0;
    height: 0;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.3);
    transform: translate(-50%, -50%);
    transition: width 0.3s, height 0.3s;
  }
  
  &:hover {
    background: ${e=>e.active?"linear-gradient(135deg, #357abd 0%, #2868a3 100())":"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(255, 255, 255, 0.15)":"rgba(0, 0, 0, 0.1)"};
    transform: scale(1.05);
    box-shadow: ${e=>e.active?"0 6px 16px rgba(74, 144, 226, 0.4), inset 0 1px 0 rgba(255, 255, 255, 0.3)":"0 4px 12px rgba(0, 0, 0, 0.1)"};
  }
  
  &:active::after {
    width: 40px;
    height: 40px;
  }
  
  & > span {
    display: inline-block;
    transform: translateY(-1px);
    z-index: 1;
  }
`,M=(0,o.Z)(R)`
  display: flex;
  align-items: center;
  justify-content: center;
`,B=e=>{let{themeConfig:t,onSelect:i}=e;t=C.getConfig();let[r,a]=(0,s.useState)(()=>{try{let e=localStorage.getItem("turnip-theme-selector-visible");return!e||"true"===e}catch(e){return console.warn("Failed to load theme selector visibility:",e),!0}}),[l,o]=(0,s.useState)(()=>{try{let e=localStorage.getItem("turnip-theme-mode");return!!e&&"dark"===e}catch(e){return console.warn("Failed to load theme mode:",e),!1}}),[d,c]=(0,s.useState)(()=>{try{return localStorage.getItem("turnip-theme-preset")||t.default.id}catch(e){return console.warn("Failed to load theme preset:",e),t.default.id}}),[h,x]=(0,s.useState)(()=>{try{let e=localStorage.getItem("turnip-theme-auto");return!!e&&"true"===e}catch(e){return console.warn("Failed to load auto mode:",e),!1}});(0,s.useEffect)(()=>{try{localStorage.setItem("turnip-theme-mode",l?"dark":"light"),localStorage.setItem("turnip-theme-auto",String(h)),localStorage.setItem("turnip-theme-preset",d),localStorage.setItem("turnip-theme-selector-visible",String(r))}catch(e){console.warn("Failed to save theme settings:",e)}},[l,h,d,r]),(0,s.useEffect)(()=>{if(!(t.presets.some(e=>e.id===d)||d===t.default.id)){var e;c((null===(e=t.presets[0])||void 0===e?void 0:e.id)||t.default.id)}},[t,d]),(0,s.useEffect)(()=>{let e=()=>{if(!h)return;let e=new Date().getHours(),t=e>=18||e<6;t!==l&&o(t)};e();let t=setInterval(e,6e4);return()=>clearInterval(t)},[h,l]);let p=(0,s.useCallback)(()=>{let e=t.presets.find(e=>e.id===d)||t.presets[0]||t.default,r={id:"custom",name:l?"暗黑主题":"明亮主题",backgroundImage:l?"linear-gradient(120deg, #2d3436 0%, #2d3436 100%)":e.backgroundImage,blur:e.blur,opacity:l?.85:e.opacity};return i(r),r},[l,d,i,t]),g=(0,s.useMemo)(()=>{let e=t.presets.find(e=>e.id===d)||t.presets[0]||t.default;return{id:"custom",name:l?"暗黑主题":"明亮主题",backgroundImage:l?"linear-gradient(120deg, #2d3436 0%, #2d3436 100%)":e.backgroundImage,blur:e.blur,opacity:l?.85:e.opacity}},[l,d,t]);return(0,s.useEffect)(()=>{p()},[l,p]),(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)($,{onClick:()=>{console.log("点击切换按钮，当前状态:",r),a(!r)},title:r?"隐藏主题选择器":"显示主题选择器",children:r?"\uD83D\uDE48":"\uD83C\uDFA8"}),(0,n.jsxs)(O,{isVisible:r,children:[!l&&(0,n.jsx)(V,{children:t.presets.map(e=>(0,n.jsx)(F,{theme:g,isSelected:d===e.id,onClick:()=>c(e.id),title:e.name,style:{background:e.backgroundImage}},e.id))}),(0,n.jsxs)(L,{children:[(0,n.jsx)(R,{theme:g,active:l,onClick:()=>{x(!1),o(!l)},title:l?"切换到明亮模式":"切换到暗黑模式",children:l?(0,n.jsx)("span",{children:"\uD83C\uDF19"}):(0,n.jsx)("span",{children:"☀️"})}),(0,n.jsx)(M,{theme:g,active:h,onClick:()=>x(!h),title:h?"关闭自动切换":"开启自动切换",children:"\uD83D\uDD52"})]})]})]})},Y=o.Z.div`
  position: absolute;
  top: 1rem;
  right: 1rem;
  font-size: 1rem;
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#2c3e50"};
  font-weight: 500;
  font-family: 'SF Mono', Monaco, 'Cascadia Code', 'Roboto Mono', Consolas, 'Courier New', monospace;
  background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(0, 0, 0, 0.6)":"rgba(255, 255, 255, 0.9)"};
  padding: 0.75rem 1rem;
  border-radius: 12px;
  box-shadow: 
    0 4px 12px rgba(0, 0, 0, 0.1),
    0 1px 3px rgba(0, 0, 0, 0.05);
  backdrop-filter: blur(8px);
  -webkit-backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  z-index: 1000;
  transition: all 0.3s ease;
  
  /* 添加微妙的动画效果 */
  animation: clockFadeIn 0.8s ease-out 0.6s both;
  
  @keyframes clockFadeIn {
    from {
      opacity: 0;
      transform: translateY(-10px) translateX(10px);
    }
    to {
      opacity: 1;
      transform: translateY(0) translateX(0);
    }
  }
  
  &:hover {
    transform: translateY(-2px);
    box-shadow: 
      0 8px 20px rgba(0, 0, 0, 0.15),
      0 2px 6px rgba(0, 0, 0, 0.1);
  }

  @media (max-width: 768px) {
    font-size: 0.875rem;
    padding: 0.6rem 0.8rem;
    top: 0.75rem;
    right: 0.75rem;
    border-radius: 10px;
  }
  
  @media (max-width: 480px) {
    font-size: 0.8rem;
    padding: 0.5rem 0.7rem;
    top: 0.5rem;
    right: 0.5rem;
    border-radius: 8px;
  }
`,K=()=>{let[e,t]=(0,s.useState)(new Date);(0,s.useEffect)(()=>{let e=setInterval(()=>{t(new Date)},1e3);return()=>clearInterval(e)},[]);let{date:i,time:r}=(e=>{let t=e.getFullYear(),i=String(e.getMonth()+1).padStart(2,"0"),r=String(e.getDate()).padStart(2,"0"),n=String(e.getHours()).padStart(2,"0"),s=String(e.getMinutes()).padStart(2,"0"),a=String(e.getSeconds()).padStart(2,"0");return{date:`${t}-${i}-${r}`,time:`${n}:${s}:${a}`}})(e);return(0,n.jsx)(Y,{children:(0,n.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:"2px"},children:[(0,n.jsx)("div",{style:{fontSize:"0.85em",opacity:.8},children:i}),(0,n.jsx)("div",{style:{fontSize:"1em",fontWeight:600},children:r})]})})};var G=((r={})[r.THEME_ADMIN_PANEL=0]="THEME_ADMIN_PANEL",r[r.SITE_ADMIN_PANEL=1]="SITE_ADMIN_PANEL",r[r.LINKS_ADMIN_PANEL=2]="LINKS_ADMIN_PANEL",r[r.VERSION_ADMIN_PANEL=3]="VERSION_ADMIN_PANEL",r[r.ANTD_SHOWCASE_PANEL=4]="ANTD_SHOWCASE_PANEL",r),J=i(7125),H=i(7205),q=i(4457),W=i(513),U=i(7890),X=i(8912),Q=i(9206),ee=i(4945),et=i(4186),ei=i(9486),er=i(9017),en=i(7318),es=i(6810),ea=i(6804),el=i(4516),eo=i(5404),ed=i(1060),ec=i(579),eh=i(5915),ex=i(5065),ep=i(9440),eg=i(5297),em=i(9425),eu=i(5793),ef=i(5473),ej=i(4220);let ey=["\uD83D\uDD17","\uD83C\uDF10","\uD83D\uDCDA","\uD83C\uDFB5","\uD83C\uDFAC","\uD83C\uDFAE","\uD83D\uDCBB","\uD83D\uDCF1","\uD83D\uDED2","\uD83D\uDCE7","\uD83D\uDCF0","\uD83D\uDD0D","⭐","❤️","\uD83C\uDFE0","\uD83C\uDFA8","\uD83D\uDCCA","\uD83D\uDCBC","\uD83D\uDD27","⚙️","\uD83D\uDCDD","\uD83D\uDCCB","\uD83D\uDCCC","\uD83C\uDFF7️"],{Title:eb,Paragraph:eZ,Text:ev}=J.Z,eS=e=>{let{value:t,onChange:i}=e,[r,a]=(0,s.useState)(""),[l,o]=(0,s.useState)(!1),d=e=>{null==i||i(e),o(!1)},c=()=>{r.trim()&&(null==i||i(r.trim()),a(""),o(!1))};return(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{style:{marginBottom:12},children:(0,n.jsx)(ev,{strong:!0,children:"常用图标："})}),(0,n.jsx)("div",{style:{marginBottom:12},children:ey.map(e=>(0,n.jsx)(H.ZP,{type:t===e?"primary":"default",size:"small",style:{margin:"2px",minWidth:"36px"},onClick:()=>d(e),children:e},e))}),(0,n.jsx)("div",{children:l?(0,n.jsxs)(q.Z.Compact,{style:{width:"100%"},children:[(0,n.jsx)(W.Z,{size:"small",placeholder:"输入自定义图标",value:r,onChange:e=>a(e.target.value),onPressEnter:c}),(0,n.jsx)(H.ZP,{size:"small",type:"primary",onClick:c,children:"确定"}),(0,n.jsx)(H.ZP,{size:"small",onClick:()=>o(!1),children:"取消"})]}):(0,n.jsx)(H.ZP,{type:"dashed",size:"small",icon:(0,n.jsx)(ec.Z,{}),onClick:()=>o(!0),children:"自定义图标"})}),t&&(0,n.jsxs)("div",{style:{marginTop:8},children:[(0,n.jsx)(ev,{type:"secondary",children:"当前选中："}),(0,n.jsx)("span",{style:{fontSize:"18px",marginLeft:"8px"},children:t})]})]})},ek=()=>{let[e,t]=(0,s.useState)([]),[i,r]=(0,s.useState)(!1),[a,l]=(0,s.useState)(!1),[o,d]=(0,s.useState)(!1),[c,h]=(0,s.useState)(!1),[x,p]=(0,s.useState)(null),[g,m]=(0,s.useState)(null),[u,f]=(0,s.useState)(null),[j,y]=(0,s.useState)(null),[b,Z]=(0,s.useState)(!1),[v]=U.Z.useForm(),[S]=U.Z.useForm();(0,s.useEffect)(()=>{k()},[]);let k=async()=>{try{r(!0);let e=T.getAllCategories();t(e)}catch(e){X.ZP.error("加载分类数据失败")}finally{r(!1)}},w=e=>{p(e||null),v.resetFields(),e&&v.setFieldsValue(e),l(!0)},I=async()=>{try{let e=await v.validateFields();x?(T.updateCategory(x.id,e.name),X.ZP.success("分类更新成功！")):(T.addCategory(e.name),X.ZP.success("分类添加成功！")),await k(),l(!1)}catch(e){X.ZP.error("操作失败，请重试")}},C=async e=>{try{T.deleteCategory(e),await k(),X.ZP.success("分类删除成功！")}catch(e){X.ZP.error("删除失败，请重试")}},E=function(e,t){let i=arguments.length>2&&void 0!==arguments[2]&&arguments[2];m(e||null),y(t||null),S.resetFields(),e&&t?S.setFieldsValue({...e,categoryId:t}):t&&S.setFieldsValue({categoryId:t}),Z(i),d(!0)},P=e=>{f(e),h(!0)},A=async()=>{try{let e=await S.validateFields();g&&j?(T.updateLink(j,g.id,{name:e.name,url:e.url,icon:e.icon}),X.ZP.success("链接更新成功！")):(T.addLink(e.categoryId,e.name,e.url,e.icon),X.ZP.success("链接添加成功！")),await k(),d(!1)}catch(e){X.ZP.error("操作失败，请重试")}},D=async(e,t)=>{try{T.deleteLink(e,t),await k(),X.ZP.success("链接删除成功！")}catch(e){X.ZP.error("删除失败，请重试")}},_=async()=>{try{T.clearStorage(),await k(),X.ZP.success("所有数据清空成功！")}catch(e){X.ZP.error("清空失败，请重试")}},N=[{title:"ID",dataIndex:"id",key:"id",width:80,sorter:(e,t)=>e.id-t.id},{title:"分类名称",dataIndex:"name",key:"name",width:80,render:e=>(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(eh.Z,{}),(0,n.jsx)("strong",{children:e})]})},{title:"链接数量",dataIndex:"links",key:"linkCount",width:100,render:e=>(0,n.jsxs)("span",{style:{color:"#1890ff",fontWeight:"bold"},children:[(null==e?void 0:e.length)||0," 个"]})},{title:"链接列表",dataIndex:"links",key:"links",width:300,render:(e,t)=>(0,n.jsx)("div",{style:{maxHeight:120,overflow:"auto"},children:e&&e.length>0?(0,n.jsx)(Q.Z,{size:"small",dataSource:e,renderItem:e=>(0,n.jsx)(Q.Z.Item,{style:{padding:"4px 0",borderBottom:"1px solid #f0f0f0"},actions:[(0,n.jsx)(H.ZP,{type:"text",size:"small",icon:(0,n.jsx)(ex.Z,{}),onClick:()=>P(e),title:"查看详情"},"view"),(0,n.jsx)(H.ZP,{type:"text",size:"small",icon:(0,n.jsx)(ep.Z,{}),onClick:()=>E(e,t.id,!0),title:"编辑链接"},"edit"),(0,n.jsx)(ee.Z,{title:"确定删除这个链接吗？",onConfirm:()=>D(t.id,e.id),okText:"确定",cancelText:"取消",children:(0,n.jsx)(H.ZP,{type:"text",size:"small",danger:!0,icon:(0,n.jsx)(eg.Z,{}),title:"删除链接"})},"delete")],children:(0,n.jsx)(Q.Z.Item.Meta,{title:(0,n.jsxs)(q.Z,{size:"small",children:[(0,n.jsx)("span",{children:e.icon}),(0,n.jsx)("span",{children:e.name||"未命名"})]}),description:(0,n.jsx)("a",{href:e.url,target:"_blank",rel:"noopener noreferrer",style:{fontSize:"12px",color:"#666"},children:e.url.length>30?`${e.url.substring(0,30)}...`:e.url})})})}):(0,n.jsx)("div",{style:{textAlign:"center",color:"#999",padding:"20px 0"},children:"暂无链接"})})},{title:"操作",key:"action",width:200,render:(e,t)=>(0,n.jsxs)(q.Z,{size:"small",children:[(0,n.jsx)(H.ZP,{type:"text",icon:(0,n.jsx)(ec.Z,{}),onClick:()=>E(void 0,t.id,!0),title:"添加链接",children:"添加"}),(0,n.jsx)(H.ZP,{type:"text",icon:(0,n.jsx)(ep.Z,{}),onClick:()=>w(t),title:"编辑分类",children:"编辑"}),(0,n.jsx)(ee.Z,{title:"确定删除这个分类及其所有链接吗？",onConfirm:()=>C(t.id),okText:"确定",cancelText:"取消",children:(0,n.jsx)(H.ZP,{type:"text",danger:!0,icon:(0,n.jsx)(eg.Z,{}),title:"删除分类",children:"删除"})})]})}];return(0,n.jsxs)("div",{style:{padding:24},children:[(0,n.jsxs)(eb,{level:2,children:[(0,n.jsx)(em.Z,{})," 链接管理面板"]}),(0,n.jsx)(eZ,{children:"管理您的链接分类和链接内容，支持添加、编辑、删除等操作。"}),(0,n.jsxs)(et.Z,{gutter:16,style:{marginBottom:24},children:[(0,n.jsx)(ei.Z,{span:8,children:(0,n.jsx)(er.Z,{children:(0,n.jsxs)("div",{style:{textAlign:"center"},children:[(0,n.jsx)(eb,{level:3,style:{margin:0,color:"#1890ff"},children:e.length}),(0,n.jsx)(eZ,{style:{margin:0,color:"#666"},children:"分类总数"})]})})}),(0,n.jsx)(ei.Z,{span:8,children:(0,n.jsx)(er.Z,{children:(0,n.jsxs)("div",{style:{textAlign:"center"},children:[(0,n.jsx)(eb,{level:3,style:{margin:0,color:"#52c41a"},children:e.reduce((e,t)=>{var i;return e+((null===(i=t.links)||void 0===i?void 0:i.length)||0)},0)}),(0,n.jsx)(eZ,{style:{margin:0,color:"#666"},children:"链接总数"})]})})}),(0,n.jsx)(ei.Z,{span:8,children:(0,n.jsx)(er.Z,{children:(0,n.jsxs)("div",{style:{textAlign:"center"},children:[(0,n.jsx)(eb,{level:3,style:{margin:0,color:"#fa8c16"},children:e.filter(e=>e.links&&e.links.length>0).length}),(0,n.jsx)(eZ,{style:{margin:0,color:"#666"},children:"活跃分类"})]})})})]}),(0,n.jsx)("div",{style:{marginBottom:16},children:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(H.ZP,{type:"primary",icon:(0,n.jsx)(ec.Z,{}),onClick:()=>w(),children:"添加分类"}),(0,n.jsx)(H.ZP,{type:"default",icon:(0,n.jsx)(em.Z,{}),onClick:()=>E(void 0,void 0,!1),disabled:0===e.length,children:"添加链接"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(eu.Z,{}),onClick:k,loading:i,children:"刷新数据"}),(0,n.jsx)(ee.Z,{title:"确定清空所有数据吗？此操作不可恢复！",onConfirm:_,okText:"确定",cancelText:"取消",children:(0,n.jsx)(H.ZP,{danger:!0,icon:(0,n.jsx)(ef.Z,{}),children:"清空数据"})})]})}),0===e.length?(0,n.jsxs)(er.Z,{style:{textAlign:"center",padding:"40px 20px"},children:[(0,n.jsx)("div",{style:{fontSize:"48px",marginBottom:"16px"},children:"\uD83D\uDCC1"}),(0,n.jsx)(eb,{level:4,children:"暂无分类数据"}),(0,n.jsx)(eZ,{style:{color:"#666",marginBottom:"24px"},children:"您还没有创建任何链接分类，点击上方按钮开始添加吧！"}),(0,n.jsx)(H.ZP,{type:"primary",icon:(0,n.jsx)(ec.Z,{}),onClick:()=>w(),children:"创建第一个分类"})]}):(0,n.jsx)(en.Z,{dataSource:e,columns:N,rowKey:"id",loading:i,pagination:{pageSize:10,showSizeChanger:!0,showQuickJumper:!0,showTotal:(e,t)=>`第 ${t[0]}-${t[1]} 条，共 ${e} 条`},scroll:{x:800}}),(0,n.jsx)(es.Z,{title:`${x?"编辑":"添加"}分类`,open:a,onOk:I,onCancel:()=>l(!1),destroyOnClose:!0,children:(0,n.jsx)(U.Z,{form:v,layout:"vertical",children:(0,n.jsx)(U.Z.Item,{name:"name",label:"分类名称",rules:[{required:!0,message:"请输入分类名称！"},{min:1,max:20,message:"分类名称长度应在1-20个字符之间！"}],children:(0,n.jsx)(W.Z,{placeholder:"请输入分类名称"})})})}),(0,n.jsxs)(es.Z,{title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(em.Z,{style:{color:"#1890ff"}}),(0,n.jsx)("span",{style:{fontSize:"16px",fontWeight:"600"},children:g?"编辑链接":"添加链接"})]}),open:o,onOk:A,onCancel:()=>d(!1),destroyOnClose:!0,width:800,okText:g?"更新链接":"添加链接",cancelText:"取消",styles:{body:{padding:"24px"}},children:[b&&(0,n.jsx)("div",{style:{background:"linear-gradient(90deg, #f6ffed 0%, #f0f9f0 100%)",border:"1px solid #b7eb8f",borderRadius:"8px",padding:"16px",marginBottom:"24px"},children:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)("span",{style:{color:"#52c41a",fontSize:"16px",fontWeight:"bold"},children:"✓"}),(0,n.jsxs)("div",{children:[(0,n.jsx)(ev,{style:{color:"#389e0d",fontWeight:"600"},children:"已自动选中分类"}),(0,n.jsx)("br",{}),(0,n.jsx)(ev,{style:{color:"#52c41a",fontSize:"12px"},children:"若需更改分类，请从上方“添加链接”按钮进入"})]})]})}),(0,n.jsxs)(U.Z,{form:S,layout:"vertical",children:[(0,n.jsx)(er.Z,{size:"small",title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(eh.Z,{style:{color:"#1890ff"}}),(0,n.jsx)("span",{children:"所属分类"})]}),style:{marginBottom:20},headStyle:{background:"#fafafa"},children:(0,n.jsx)(U.Z.Item,{name:"categoryId",rules:[{required:!0,message:"请选择分类！"}],children:(0,n.jsx)(ea.Z,{placeholder:"请选择一个分类",disabled:b,size:"large",options:e.map(e=>{var t;return{value:e.id,label:(0,n.jsxs)("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"4px 0"},children:[(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(eh.Z,{style:{color:"#1890ff"}}),(0,n.jsx)("span",{style:{fontWeight:"500"},children:e.name})]}),(0,n.jsxs)("span",{style:{color:"#999",fontSize:"12px",fontStyle:"italic"},children:[(null===(t=e.links)||void 0===t?void 0:t.length)||0," 个链接"]})]})}})})})}),(0,n.jsxs)(er.Z,{size:"small",title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(em.Z,{style:{color:"#52c41a"}}),(0,n.jsx)("span",{children:"基本信息"})]}),style:{marginBottom:20},headStyle:{background:"#fafafa"},children:[(0,n.jsxs)(et.Z,{gutter:16,children:[(0,n.jsx)(ei.Z,{span:16,children:(0,n.jsx)(U.Z.Item,{name:"name",label:"链接名称",rules:[{max:30,message:"链接名称不能超过30个字符！"}],children:(0,n.jsx)(W.Z,{placeholder:"请输入链接名称（可选）",size:"large",prefix:(0,n.jsx)("span",{style:{color:"#666",fontSize:"14px"},children:"\uD83D\uDCDD"})})})}),(0,n.jsx)(ei.Z,{span:8,children:(0,n.jsx)(U.Z.Item,{name:"icon",label:"链接图标",rules:[{required:!0,message:"请选择图标！"},{max:10,message:"图标不能超过10个字符！"}],children:(0,n.jsx)(eS,{})})})]}),(0,n.jsx)(U.Z.Item,{name:"url",label:"链接地址",rules:[{required:!0,message:"请输入链接地址！"},{type:"url",message:"请输入有效的URL地址！"}],children:(0,n.jsx)(W.Z,{placeholder:"https://example.com",size:"large",prefix:(0,n.jsx)(ej.Z,{style:{color:"#1890ff"}}),suffix:(0,n.jsx)(el.Z,{title:"测试链接",children:(0,n.jsx)(H.ZP,{type:"text",size:"small",icon:(0,n.jsx)(ex.Z,{}),onClick:()=>{let e=S.getFieldValue("url");if(e)try{window.open(e,"_blank"),X.ZP.success("链接已在新窗口中打开")}catch(e){X.ZP.error("无法打开链接，请检查URL格式")}else X.ZP.warning("请先输入链接地址")},style:{color:"#52c41a"}})})})})]}),(0,n.jsxs)(er.Z,{size:"small",title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(ex.Z,{style:{color:"#fa8c16"}}),(0,n.jsx)("span",{children:"预览效果"})]}),style:{background:"#fafafa"},headStyle:{background:"#f0f0f0"},children:[(0,n.jsx)("div",{style:{padding:"20px",border:"2px dashed #d9d9d9",borderRadius:"12px",textAlign:"center",background:"white",transition:"all 0.3s ease"},children:(0,n.jsx)(U.Z.Item,{dependencies:["icon","name","url"],noStyle:!0,children:e=>{let{getFieldValue:t}=e,i=t("icon"),r=t("name"),s=t("url");return(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{style:{fontSize:"48px",marginBottom:"12px",filter:"drop-shadow(0 2px 4px rgba(0,0,0,0.1))"},children:i||"\uD83D\uDD17"}),(0,n.jsx)("div",{style:{fontSize:"16px",fontWeight:"600",color:"#333",marginBottom:"8px",minHeight:"20px"},children:r||"未命名链接"}),(0,n.jsx)("div",{style:{fontSize:"12px",color:"#999",wordBreak:"break-all",lineHeight:"1.5",maxHeight:"40px",overflow:"hidden"},children:s?s.length>50?`${s.substring(0,50)}...`:s:"https://example.com"})]})}})}),(0,n.jsx)("div",{style:{textAlign:"center",marginTop:"12px"},children:(0,n.jsx)(ev,{type:"secondary",style:{fontSize:"12px"},children:"✨ 这是链接在主页面中的显示效果预览"})})]})]})]}),(0,n.jsx)(es.Z,{title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(ex.Z,{}),"链接详情"]}),open:c,onCancel:()=>h(!1),footer:[(0,n.jsx)(H.ZP,{type:"primary",onClick:()=>{if(u){let t=e.find(e=>{var t;return null===(t=e.links)||void 0===t?void 0:t.some(e=>e.id===u.id)});h(!1),E(u,null==t?void 0:t.id,!0)}},children:"编辑链接"},"edit"),(0,n.jsx)(H.ZP,{onClick:()=>h(!1),children:"关闭"},"close")],width:600,children:u&&(0,n.jsx)("div",{children:(0,n.jsxs)(eo.Z,{column:1,bordered:!0,children:[(0,n.jsx)(eo.Z.Item,{label:"链接ID",children:u.id}),(0,n.jsx)(eo.Z.Item,{label:"图标",children:(0,n.jsx)(ed.Z,{shape:"square",size:40,style:{backgroundColor:"#f0f0f0"},children:(0,n.jsx)("span",{style:{fontSize:"20px"},children:u.icon})})}),(0,n.jsx)(eo.Z.Item,{label:"名称",children:u.name||(0,n.jsx)("span",{style:{color:"#999"},children:"未命名"})}),(0,n.jsx)(eo.Z.Item,{label:"链接地址",children:(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{style:{marginBottom:8},children:(0,n.jsx)("a",{href:u.url,target:"_blank",rel:"noopener noreferrer",style:{wordBreak:"break-all"},children:u.url})}),(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(H.ZP,{size:"small",icon:(0,n.jsx)(ej.Z,{}),onClick:()=>window.open(u.url,"_blank"),children:"打开链接"}),(0,n.jsx)(H.ZP,{size:"small",onClick:()=>{navigator.clipboard.writeText(u.url),X.ZP.success("链接地址已复制到剪贴板")},children:"复制链接"})]})]})}),(0,n.jsx)(eo.Z.Item,{label:"所属分类",children:(()=>{let t=e.find(e=>{var t;return null===(t=e.links)||void 0===t?void 0:t.some(e=>e.id===u.id)});return t?(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(eh.Z,{}),t.name]}):"未知分类"})()})]})})})]})};var ew=i(2085),eI=i(3974);let{Title:eC,Paragraph:eE}=J.Z,eP=()=>{let[e]=U.Z.useForm(),[t,i]=(0,s.useState)([]),[r,a]=(0,s.useState)(null),[l,o]=(0,s.useState)(!1),[d,c]=(0,s.useState)(null),[h,x]=(0,s.useState)(null);(0,s.useEffect)(()=>{p()},[]);let p=()=>{let e=C.getConfig();i(e.presets),a(e.default)},g=t=>{c(t||null),t?e.setFieldsValue({id:t.id,name:t.name,backgroundImage:t.backgroundImage,blur:parseInt(t.blur),opacity:Math.round(100*t.opacity)}):e.resetFields(),o(!0)},m=async()=>{try{let t=await e.validateFields(),i={id:t.id,name:t.name,backgroundImage:t.backgroundImage,blur:`${t.blur}px`,opacity:t.opacity/100};d?(C.updatePreset(i),X.ZP.success("主题更新成功！")):(C.addPreset(i),X.ZP.success("主题添加成功！")),p(),o(!1),e.resetFields()}catch(e){X.ZP.error("操作失败，请检查输入")}},u=e=>{if(t.length<=1){X.ZP.warning("不能删除最后一个主题，请先添加其他主题");return}try{C.deletePreset(e),X.ZP.success("主题删除成功！"),p()}catch(e){X.ZP.error("删除失败")}},f=e=>{C.setDefaultTheme(e),X.ZP.success("默认主题设置成功！"),p()},j=e=>{x(e),X.ZP.info("主题预览功能开发中...")},y=()=>{try{[{id:"purple",name:"渐变紫",backgroundImage:"linear-gradient(to right, #6a11cb 0%, #2575fc 100%)",blur:"10px",opacity:.95},{id:"morning",name:"晨光蓝",backgroundImage:"linear-gradient(120deg, #a1c4fd 0%, #c2e9fb 100%)",blur:"10px",opacity:.95},{id:"night",name:"夜空",backgroundImage:"linear-gradient(to right, #243949 0%, #517fa4 100%)",blur:"10px",opacity:.92}].forEach(e=>{C.findThemeById(e.id)||C.addPreset(e)}),p(),X.ZP.success("默认主题恢复成功！")}catch(e){X.ZP.error("默认主题恢复失败")}},b=[{title:"ID",dataIndex:"id",key:"id",width:100},{title:"主题名称",dataIndex:"name",key:"name"},{title:"背景预览",dataIndex:"backgroundImage",key:"backgroundImage",width:120,render:e=>(0,n.jsx)("div",{style:{width:60,height:30,background:e,borderRadius:4,border:"1px solid #d9d9d9"}})},{title:"模糊度",dataIndex:"blur",key:"blur",width:80},{title:"透明度",dataIndex:"opacity",key:"opacity",width:80,render:e=>`${Math.round(100*e)}%`},{title:"操作",key:"action",width:200,render:(e,t)=>(0,n.jsxs)(q.Z,{size:"small",children:[(0,n.jsx)(H.ZP,{type:"text",icon:(0,n.jsx)(ex.Z,{}),onClick:()=>j(t),title:"预览"}),(0,n.jsx)(H.ZP,{type:"text",icon:(0,n.jsx)(ep.Z,{}),onClick:()=>g(t),title:"编辑"}),(0,n.jsx)(H.ZP,{type:"text",onClick:()=>f(t),title:"设为默认",children:"默认"}),(0,n.jsx)(ee.Z,{title:"确定删除这个主题吗？",onConfirm:()=>u(t.id),okText:"确定",cancelText:"取消",children:(0,n.jsx)(H.ZP,{type:"text",danger:!0,icon:(0,n.jsx)(eg.Z,{}),title:"删除"})})]})}];return(0,n.jsxs)("div",{style:{padding:24},children:[(0,n.jsxs)(eC,{level:2,children:[(0,n.jsx)(eI.Z,{})," 主题管理面板"]}),(0,n.jsx)(eE,{children:"管理应用的主题配置，包括背景渐变、模糊效果和透明度设置。"}),r&&(0,n.jsx)(er.Z,{title:"当前默认主题",style:{marginBottom:16},children:(0,n.jsxs)(et.Z,{gutter:16,align:"middle",children:[(0,n.jsx)(ei.Z,{span:4,children:(0,n.jsx)("div",{style:{width:80,height:40,background:r.backgroundImage,borderRadius:6,border:"1px solid #d9d9d9"}})}),(0,n.jsxs)(ei.Z,{span:20,children:[(0,n.jsx)(eC,{level:4,style:{margin:0},children:r.name}),(0,n.jsxs)(eE,{style:{margin:0,color:"#666"},children:["模糊度: ",r.blur," | 透明度: ",Math.round(100*r.opacity),"%"]})]})]})}),(0,n.jsx)("div",{style:{marginBottom:16},children:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(H.ZP,{type:"primary",icon:(0,n.jsx)(ec.Z,{}),onClick:()=>g(),children:"添加新主题"}),0===t.length&&(0,n.jsx)(H.ZP,{type:"dashed",onClick:y,children:"恢复默认主题"})]})}),0===t.length?(0,n.jsxs)(er.Z,{style:{textAlign:"center",padding:"40px 20px"},children:[(0,n.jsx)("div",{style:{fontSize:"48px",marginBottom:"16px"},children:"\uD83C\uDFA8"}),(0,n.jsx)(eC,{level:4,children:"暂无自定义主题"}),(0,n.jsx)(eE,{style:{color:"#666",marginBottom:"24px"},children:"您还没有创建任何自定义主题，可以点击上方按钮添加新主题或恢复默认主题。"}),(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(H.ZP,{type:"primary",icon:(0,n.jsx)(ec.Z,{}),onClick:()=>g(),children:"创建第一个主题"}),(0,n.jsx)(H.ZP,{onClick:y,children:"恢复默认主题"})]})]}):(0,n.jsx)(en.Z,{dataSource:t,columns:b,rowKey:"id",pagination:{pageSize:10},scroll:{x:800}}),(0,n.jsx)(es.Z,{title:d?"编辑主题":"添加新主题",open:l,onOk:m,onCancel:()=>{o(!1),e.resetFields()},width:600,okText:"保存",cancelText:"取消",children:(0,n.jsxs)(U.Z,{form:e,layout:"vertical",children:[(0,n.jsx)(U.Z.Item,{name:"id",label:"主题ID",rules:[{required:!0,message:"请输入主题ID"},{pattern:/^[a-zA-Z0-9_-]+$/,message:"ID只能包含字母、数字、下划线和连字符"}],children:(0,n.jsx)(W.Z,{placeholder:"例如: my-theme",disabled:!!d})}),(0,n.jsx)(U.Z.Item,{name:"name",label:"主题名称",rules:[{required:!0,message:"请输入主题名称"}],children:(0,n.jsx)(W.Z,{placeholder:"例如: 我的主题"})}),(0,n.jsx)(U.Z.Item,{name:"backgroundImage",label:"背景渐变",rules:[{required:!0,message:"请输入背景渐变CSS"}],children:(0,n.jsx)(W.Z.TextArea,{placeholder:"例如: linear-gradient(120deg, #f6d365 0%, #fda085 100%)",rows:3})}),(0,n.jsx)("div",{style:{marginBottom:16},children:(0,n.jsx)(H.ZP,{onClick:()=>{let t=["linear-gradient(120deg, #a8edea 0%, #fed6e3 100%)","linear-gradient(120deg, #d299c2 0%, #fef9d7 100%)","linear-gradient(120deg, #89f7fe 0%, #66a6ff 100%)","linear-gradient(120deg, #fdbb2d 0%, #22c1c3 100%)","linear-gradient(120deg, #ff9a9e 0%, #fecfef 100%)","linear-gradient(120deg, #667eea 0%, #764ba2 100%)","linear-gradient(120deg, #f093fb 0%, #f5576c 100%)","linear-gradient(120deg, #4facfe 0%, #00f2fe 100%)"],i=t[Math.floor(Math.random()*t.length)];e.setFieldValue("backgroundImage",i)},type:"dashed",block:!0,children:"\uD83C\uDFA8 随机生成渐变"})}),(0,n.jsx)(U.Z.Item,{name:"blur",label:"模糊度 (px)",rules:[{required:!0,message:"请设置模糊度"}],children:(0,n.jsx)(ew.Z,{min:0,max:20,marks:{0:"0px",10:"10px",20:"20px"}})}),(0,n.jsx)(U.Z.Item,{name:"opacity",label:"透明度 (%)",rules:[{required:!0,message:"请设置透明度"}],children:(0,n.jsx)(ew.Z,{min:10,max:100,marks:{10:"10%",50:"50%",100:"100%"}})})]})})]})};var eT=i(7526),eA=i(7616),eD=i(9325),e_=i(8217),eN=i(3802),ez=i(3382),eO=i(3854),e$=i(2437);let{Title:eL,Paragraph:eV,Text:eF}=J.Z,{TextArea:eR}=W.Z,eM=()=>{let[e]=U.Z.useForm(),[t,i]=(0,s.useState)(null),[r,a]=(0,s.useState)(!1),[l,o]=(0,s.useState)(!1),[d,c]=(0,s.useState)(!1),[h,x]=(0,s.useState)(!1),[p,g]=(0,s.useState)(!0);(0,s.useEffect)(()=>{m()},[]);let m=()=>{let t=D.getConfig();console.log("loadSiteConfig - 获取到的配置:",t),i(t);let r={title:t.title,copyright:t.copyright.text,description:t.description||"",keywords:t.keywords||"",author:t.author||"",favicon:t.favicon||""};console.log("loadSiteConfig - 设置表单值:",r),e.setFieldsValue(r),setTimeout(()=>{console.log("loadSiteConfig - 设置后实际的favicon值:",e.getFieldValue("favicon"))},50),setTimeout(()=>{let e=t.favicon;if(e){let t=document.getElementById("favicon-preview");if(t){let i=document.createElement("img");i.onload=()=>{t.style.backgroundImage=`url(${e})`,t.style.backgroundColor="transparent"},i.onerror=()=>{t.style.backgroundImage="none",t.style.backgroundColor="#ff4d4f"},i.src=e}}},100)},u=async()=>{try{a(!0);let t=await e.validateFields();console.log("handleSave - 获取到的表单值:",t);let i=e.getFieldValue("favicon");console.log("handleSave - 单独获取favicon字段:",i),console.log("handleSave - favicon类型:",typeof i),console.log("handleSave - favicon长度:",i?i.length:"undefined"),D.updateTitle(t.title),D.updateCopyright(t.copyright),t.description&&D.addConfigItem("description",t.description),t.keywords&&D.addConfigItem("keywords",t.keywords),t.author&&D.addConfigItem("author",t.author),t.favicon&&t.favicon.trim()?(console.log("handleSave - 保存favicon:",t.favicon),D.addConfigItem("favicon",t.favicon),D.updateFavicon(t.favicon)):(console.log("handleSave - favicon为空，删除配置"),D.deleteConfigItem("favicon")),X.ZP.success("网站配置保存成功！"),o(!1),m()}catch(e){X.ZP.error("保存失败，请检查输入")}finally{a(!1)}},f=()=>{o(!0)},j=async()=>{try{a(!0),p&&(_.createVersion({name:`重置前备份_${new Date().toLocaleString("zh-CN")}`,description:"系统重置前的自动备份",tags:["系统重置","自动备份"]}),X.ZP.success("当前配置已保存为版本"),await new Promise(e=>setTimeout(e,1e3))),D.resetToDefault(A),C.resetToDefault(I),T.resetToDefault(E,P),X.ZP.success("网站重置成功！页面将2秒后刷新"),setTimeout(()=>{window.location.reload()},2e3)}catch(e){X.ZP.error("重置失败，请重试")}finally{a(!1),c(!1)}},y=()=>({site:{title:D.getConfig().title,copyright:D.getConfig().copyright.text,description:D.getConfig().description||"未设置",keywords:D.getConfig().keywords||"未设置",author:D.getConfig().author||"未设置",favicon:D.getConfig().favicon||"未设置"},theme:{default:C.getDefaultTheme(),presets:C.getPresets(),totalThemes:C.getPresets().length+1},links:{categories:T.getAllCategories(),totalCategories:T.getAllCategories().length,totalLinks:T.getAllCategories().reduce((e,t)=>{var i;return e+((null===(i=t.links)||void 0===i?void 0:i.length)||0)},0),searchEngines:T.getAllSearchEngines(),totalSearchEngines:T.getAllSearchEngines().length},system:{storageSize:b(),...N.getSystemSummary()}}),b=()=>{let e=0;for(let t in localStorage)localStorage.hasOwnProperty(t)&&t.startsWith("turnip")&&(e+=localStorage[t].length);return(e/1024).toFixed(2)};return(0,n.jsxs)("div",{style:{padding:24},children:[(0,n.jsxs)(eL,{level:2,children:[(0,n.jsx)(eD.Z,{})," 网站配置面板"]}),(0,n.jsx)(eV,{children:"管理网站的基本信息、SEO配置和系统设置。"}),(0,n.jsx)(er.Z,{title:"系统状态",style:{marginBottom:16},children:(0,n.jsxs)(et.Z,{gutter:16,children:[(0,n.jsx)(ei.Z,{span:6,children:(0,n.jsx)(eT.Z,{title:"本地存储使用",value:b(),suffix:"KB",valueStyle:{color:"#1890ff"}})}),(0,n.jsx)(ei.Z,{span:6,children:(0,n.jsx)(eT.Z,{title:"主题数量",value:JSON.parse(localStorage.getItem("turnip-theme-config")||'{"presets":[]}').presets.length,valueStyle:{color:"#52c41a"}})}),(0,n.jsx)(ei.Z,{span:6,children:(0,n.jsx)(eT.Z,{title:"链接分类",value:JSON.parse(localStorage.getItem("turnip_link_categories")||"[]").length,valueStyle:{color:"#722ed1"}})}),(0,n.jsx)(ei.Z,{span:6,children:(0,n.jsx)(eT.Z,{title:"配置版本",value:N.getVersionStatusText(),valueStyle:{color:"#eb2f96",fontSize:"14px"}})})]})}),(0,n.jsxs)(er.Z,{title:"基本信息",style:{marginBottom:16},children:[(0,n.jsxs)(U.Z,{form:e,layout:"vertical",onValuesChange:f,children:[(0,n.jsxs)(et.Z,{gutter:16,children:[(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsx)(U.Z.Item,{name:"title",label:"网站标题",rules:[{required:!0,message:"请输入网站标题"}],children:(0,n.jsx)(W.Z,{placeholder:"例如: Turnip起始页",prefix:(0,n.jsx)(ej.Z,{})})})}),(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsx)(U.Z.Item,{name:"author",label:"作者",children:(0,n.jsx)(W.Z,{placeholder:"例如: Turnip1202"})})})]}),(0,n.jsx)(U.Z.Item,{name:"description",label:"网站描述",children:(0,n.jsx)(eR,{rows:3,placeholder:"网站的简短描述，用于SEO优化"})}),(0,n.jsx)(U.Z.Item,{name:"keywords",label:"关键词",children:(0,n.jsx)(W.Z,{placeholder:"多个关键词用逗号分隔，例如: 起始页,导航,工具"})}),(0,n.jsx)(U.Z.Item,{name:"copyright",label:"版权信息",rules:[{required:!0,message:"请输入版权信息"}],children:(0,n.jsx)(W.Z,{placeholder:"例如: \xa9 2024 Turnip1202. All rights reserved."})}),(0,n.jsxs)(q.Z.Compact,{block:!0,style:{display:"flex",width:"100%",flexDirection:"column"},children:[(0,n.jsxs)("div",{style:{display:"flex",width:"100%",alignItems:"center"},children:[(0,n.jsx)(U.Z.Item,{name:"favicon",label:"网站图标URL",style:{flex:1,marginBottom:0},children:(0,n.jsx)(W.Z,{placeholder:"例如: /favicon.ico",onChange:e=>{let t=e.target.value;if(f(),t&&t.trim())setTimeout(()=>{let e=document.createElement("img");e.onload=()=>{let e=document.getElementById("favicon-preview");e&&(e.style.backgroundImage=`url(${t})`,e.style.backgroundColor="transparent")},e.onerror=()=>{let e=document.getElementById("favicon-preview");e&&(e.style.backgroundImage="none",e.style.backgroundColor="#ff4d4f")},e.src=t},500);else{let e=document.getElementById("favicon-preview");e&&(e.style.backgroundImage="none",e.style.backgroundColor="#f0f0f0")}}})}),(0,n.jsx)("div",{id:"favicon-preview",style:{width:"32px",height:"32px",border:"1px solid #d9d9d9",borderLeft:"none",borderRadius:"0 6px 6px 0",backgroundSize:"contain",backgroundRepeat:"no-repeat",backgroundPosition:"center",backgroundColor:"#f0f0f0",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"12px",marginTop:"30px",color:"#666",marginLeft:"-1px"},title:"图标预览",children:"\uD83C\uDF10"})]}),(0,n.jsx)("div",{style:{fontSize:"12px",color:"#666",marginTop:"4px",paddingLeft:"12px"},children:"支持 .ico、.png、.svg 等格式，建议尺寸 16\xd716 或 32\xd732 像素"})]})]}),l&&(0,n.jsx)(eA.Z,{message:"您有未保存的更改",description:"请记得保存您的配置更改",type:"warning",showIcon:!0,style:{marginBottom:16}}),(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(H.ZP,{type:"primary",icon:(0,n.jsx)(e_.Z,{}),loading:r,onClick:u,disabled:!l,children:"保存配置"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(eu.Z,{}),onClick:()=>{m(),o(!1),X.ZP.info("配置已重置")},disabled:!l,children:"重置"})]})]}),(0,n.jsx)(er.Z,{title:"高级设置",style:{marginBottom:16},children:(0,n.jsxs)(q.Z,{direction:"vertical",style:{width:"100%"},children:[(0,n.jsx)(eA.Z,{message:"危险操作",description:"以下操作可能会影响应用的正常使用，请谨慎操作",type:"error",showIcon:!0}),(0,n.jsxs)("div",{children:[(0,n.jsx)(eL,{level:5,style:{marginBottom:8},children:"\uD83D\uDCCB 版本管理与数据备份"}),(0,n.jsxs)(q.Z,{wrap:!0,children:[(0,n.jsx)(H.ZP,{type:"primary",icon:(0,n.jsx)(e_.Z,{}),onClick:()=>{let e={name:`网站配置快照_${new Date().toLocaleDateString("zh-CN")}`,description:"从网站配置面板创建的配置快照",tags:["手动保存","网站配置"]};_.createVersion(e),X.ZP.success("配置版本已保存！")},children:"保存当前版本"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(eN.Z,{}),onClick:()=>{X.ZP.info('请通过管理面板中的"配置版本管理"查看所有版本')},children:"查看版本历史"}),(0,n.jsx)(H.ZP,{type:"dashed",icon:(0,n.jsx)(ez.Z,{}),onClick:()=>{let e=new Blob([_.exportVersions()],{type:"application/json"}),t=URL.createObjectURL(e),i=document.createElement("a");i.href=t,i.download=`turnip_versions_${new Date().toISOString().split("T")[0]}.json`,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(t),X.ZP.success("版本数据导出成功")},children:"导出版本数据"}),(0,n.jsx)(H.ZP,{type:"default",icon:(0,n.jsx)(ex.Z,{}),onClick:()=>x(!0),children:"配置预览"})]})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(eL,{level:5,style:{marginBottom:8},children:"\uD83D\uDDD1️ 数据清理"}),(0,n.jsxs)(q.Z,{wrap:!0,children:[(0,n.jsx)(H.ZP,{danger:!0,icon:(0,n.jsx)(ef.Z,{}),onClick:()=>{D.clearStorage(),X.ZP.success("本地存储已清除"),setTimeout(()=>{window.location.reload()},1e3)},children:"清除所有数据"}),(0,n.jsx)(H.ZP,{danger:!0,type:"primary",icon:(0,n.jsx)(eO.Z,{}),onClick:()=>c(!0),children:"重置网站"})]})]})]})}),t&&(0,n.jsx)(er.Z,{title:"当前配置预览",children:(0,n.jsx)("div",{style:{background:"#f5f5f5",padding:16,borderRadius:6},children:(0,n.jsx)("pre",{style:{margin:0,fontSize:12},children:JSON.stringify(t,null,2)})})}),(0,n.jsx)(es.Z,{title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(e$.Z,{style:{color:"#ff4d4f"}}),(0,n.jsx)("span",{children:"重置网站"})]}),open:d,onOk:j,onCancel:()=>c(!1),okText:"确认重置",cancelText:"取消",okButtonProps:{danger:!0,loading:r},width:600,centered:!0,children:(0,n.jsxs)("div",{style:{padding:"20px 0"},children:[(0,n.jsx)(eA.Z,{message:"警告：此操作不可逆转！",description:"这将会清除所有当前数据并重置为默认配置",type:"error",showIcon:!0,style:{marginBottom:20}}),(0,n.jsxs)("div",{style:{marginBottom:16},children:[(0,n.jsx)(eF,{strong:!0,children:"重置将影响的数据："}),(0,n.jsxs)("ul",{style:{marginTop:8,paddingLeft:20},children:[(0,n.jsx)("li",{children:"\uD83C\uDF10 网站配置（标题、版权、SEO信息等）"}),(0,n.jsx)("li",{children:"\uD83C\uDFA8 主题设置（自定义主题将被清除）"}),(0,n.jsx)("li",{children:"\uD83D\uDD17 链接数据（所有分类和链接）"}),(0,n.jsx)("li",{children:"\uD83D\uDD0D 搜索引擎配置"})]})]}),(0,n.jsxs)("div",{style:{marginBottom:16},children:[(0,n.jsx)(eF,{strong:!0,children:"重置后将恢复为："}),(0,n.jsxs)("ul",{style:{marginTop:8,paddingLeft:20},children:[(0,n.jsx)("li",{children:"✅ 默认网站标题和信息"}),(0,n.jsx)("li",{children:"✅ 默认主题集合（渐变紫、晨光蓝、夜空）"}),(0,n.jsx)("li",{children:"✅ 默认链接分类和示例链接"}),(0,n.jsx)("li",{children:"✅ 默认搜索引擎（百度、谷歌、必应）"})]})]}),(0,n.jsx)("div",{style:{background:"#f6ffed",border:"1px solid #b7eb8f",borderRadius:"6px",padding:"12px"},children:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)("input",{type:"checkbox",checked:p,onChange:e=>g(e.target.checked),id:"backup-checkbox"}),(0,n.jsx)("label",{htmlFor:"backup-checkbox",style:{cursor:"pointer"},children:(0,n.jsx)(eF,{style:{color:"#52c41a"},children:"在重置前自动导出完整备份（建议勾选）"})})]})})]})}),(0,n.jsx)(es.Z,{title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(ex.Z,{style:{color:"#52c41a"}}),(0,n.jsx)("span",{children:"当前网站配置预览"})]}),open:h,onCancel:()=>x(!1),footer:[(0,n.jsx)(H.ZP,{onClick:()=>{let e="data:application/json;charset=utf-8,"+encodeURIComponent(JSON.stringify(y(),null,2)),t=document.createElement("a");t.setAttribute("href",e),t.setAttribute("download",`turnip-config-preview-${new Date().toISOString().split("T")[0]}.json`),t.click(),X.ZP.success("配置预览已导出")},children:"导出预览"},"export"),(0,n.jsx)(H.ZP,{type:"primary",onClick:()=>x(!1),children:"关闭"},"close")],width:900,centered:!0,style:{top:20},children:(()=>{let e=y();return(0,n.jsxs)("div",{style:{maxHeight:"70vh",overflow:"auto"},children:[(0,n.jsx)(er.Z,{size:"small",title:"\uD83C\uDF10 网站基本信息",style:{marginBottom:16},children:(0,n.jsxs)(et.Z,{gutter:[16,8],children:[(0,n.jsxs)(ei.Z,{span:12,children:[(0,n.jsx)(eF,{strong:!0,children:"网站标题："}),(0,n.jsx)("div",{style:{marginTop:4,padding:"4px 8px",background:"#f5f5f5",borderRadius:"4px"},children:e.site.title})]}),(0,n.jsxs)(ei.Z,{span:12,children:[(0,n.jsx)(eF,{strong:!0,children:"作者："}),(0,n.jsx)("div",{style:{marginTop:4,padding:"4px 8px",background:"#f5f5f5",borderRadius:"4px"},children:e.site.author})]}),(0,n.jsxs)(ei.Z,{span:24,children:[(0,n.jsx)(eF,{strong:!0,children:"版权信息："}),(0,n.jsx)("div",{style:{marginTop:4,padding:"4px 8px",background:"#f5f5f5",borderRadius:"4px"},children:e.site.copyright})]}),(0,n.jsxs)(ei.Z,{span:24,children:[(0,n.jsx)(eF,{strong:!0,children:"网站描述："}),(0,n.jsx)("div",{style:{marginTop:4,padding:"4px 8px",background:"#f5f5f5",borderRadius:"4px"},children:e.site.description})]}),(0,n.jsxs)(ei.Z,{span:12,children:[(0,n.jsx)(eF,{strong:!0,children:"关键词："}),(0,n.jsx)("div",{style:{marginTop:4,padding:"4px 8px",background:"#f5f5f5",borderRadius:"4px"},children:e.site.keywords})]}),(0,n.jsxs)(ei.Z,{span:12,children:[(0,n.jsx)(eF,{strong:!0,children:"网站图标："}),(0,n.jsx)("div",{style:{marginTop:4,padding:"4px 8px",background:"#f5f5f5",borderRadius:"4px"},children:e.site.favicon})]})]})}),(0,n.jsx)(er.Z,{size:"small",title:"\uD83C\uDFA8 主题配置",style:{marginBottom:16},children:(0,n.jsxs)(et.Z,{gutter:[16,8],children:[(0,n.jsx)(ei.Z,{span:24,children:(0,n.jsxs)("div",{style:{marginBottom:12},children:[(0,n.jsx)(eF,{strong:!0,children:"当前默认主题："}),(0,n.jsx)("div",{style:{marginTop:8,padding:"12px",border:"1px solid #d9d9d9",borderRadius:"8px",background:"#fafafa"},children:(0,n.jsxs)(et.Z,{align:"middle",gutter:16,children:[(0,n.jsx)(ei.Z,{span:4,children:(0,n.jsx)("div",{style:{width:60,height:30,background:e.theme.default.backgroundImage,borderRadius:"4px",border:"1px solid #d9d9d9"}})}),(0,n.jsx)(ei.Z,{span:20,children:(0,n.jsxs)("div",{children:[(0,n.jsx)(eF,{strong:!0,children:e.theme.default.name}),(0,n.jsx)("br",{}),(0,n.jsxs)(eF,{type:"secondary",style:{fontSize:"12px"},children:["模糊度: ",e.theme.default.blur," | 透明度: ",Math.round(100*e.theme.default.opacity),"%"]})]})})]})})]})}),(0,n.jsxs)(ei.Z,{span:24,children:[(0,n.jsxs)(eF,{strong:!0,children:["预设主题 (",e.theme.presets.length," 个)："]}),(0,n.jsx)("div",{style:{marginTop:8},children:e.theme.presets.length>0?(0,n.jsx)(et.Z,{gutter:[8,8],children:e.theme.presets.map((e,t)=>(0,n.jsx)(ei.Z,{span:8,children:(0,n.jsxs)("div",{style:{padding:"8px",border:"1px solid #d9d9d9",borderRadius:"6px",background:"#fafafa"},children:[(0,n.jsx)("div",{style:{width:"100%",height:20,background:e.backgroundImage,borderRadius:"3px",marginBottom:"4px"}}),(0,n.jsx)(eF,{style:{fontSize:"12px"},children:e.name})]})},e.id))}):(0,n.jsx)("div",{style:{padding:"20px",textAlign:"center",color:"#999"},children:"暂无预设主题"})})]})]})}),(0,n.jsxs)(er.Z,{size:"small",title:"\uD83D\uDD17 链接数据",style:{marginBottom:16},children:[(0,n.jsxs)(et.Z,{gutter:[16,8],style:{marginBottom:16},children:[(0,n.jsx)(ei.Z,{span:8,children:(0,n.jsx)(eT.Z,{title:"分类数量",value:e.links.totalCategories,valueStyle:{color:"#1890ff",fontSize:"18px"}})}),(0,n.jsx)(ei.Z,{span:8,children:(0,n.jsx)(eT.Z,{title:"链接数量",value:e.links.totalLinks,valueStyle:{color:"#52c41a",fontSize:"18px"}})}),(0,n.jsx)(ei.Z,{span:8,children:(0,n.jsx)(eT.Z,{title:"搜索引擎",value:e.links.totalSearchEngines,valueStyle:{color:"#fa8c16",fontSize:"18px"}})})]}),e.links.categories.length>0&&(0,n.jsxs)("div",{children:[(0,n.jsx)(eF,{strong:!0,children:"分类详情："}),(0,n.jsx)("div",{style:{marginTop:8,maxHeight:200,overflow:"auto"},children:e.links.categories.map(e=>{var t;return(0,n.jsxs)("div",{style:{marginBottom:"8px",padding:"8px",border:"1px solid #f0f0f0",borderRadius:"4px",background:"#fafafa"},children:[(0,n.jsxs)(et.Z,{justify:"space-between",align:"middle",children:[(0,n.jsx)(ei.Z,{children:(0,n.jsx)(eF,{strong:!0,children:e.name})}),(0,n.jsx)(ei.Z,{children:(0,n.jsxs)(eF,{type:"secondary",children:[(null===(t=e.links)||void 0===t?void 0:t.length)||0," 个链接"]})})]}),e.links&&e.links.length>0&&(0,n.jsxs)("div",{style:{marginTop:4,fontSize:"12px",color:"#666"},children:[e.links.slice(0,3).map(e=>e.icon+" "+(e.name||"未命名")).join(", "),e.links.length>3&&"..."]})]},e.id)})})]})]}),(0,n.jsx)(er.Z,{size:"small",title:"⚙️ 系统信息",children:(0,n.jsxs)(et.Z,{gutter:[16,8],children:[(0,n.jsxs)(ei.Z,{span:8,children:[(0,n.jsx)(eF,{strong:!0,children:"存储大小："}),(0,n.jsx)("div",{style:{marginTop:4},children:(0,n.jsxs)(eF,{children:[e.system.storageSize," KB"]})})]}),(0,n.jsxs)(ei.Z,{span:8,children:[(0,n.jsx)(eF,{strong:!0,children:"项目版本："}),(0,n.jsx)("div",{style:{marginTop:4},children:(0,n.jsx)(eF,{children:e.system.projectVersion})})]}),(0,n.jsxs)(ei.Z,{span:8,children:[(0,n.jsx)(eF,{strong:!0,children:"生成时间："}),(0,n.jsx)("div",{style:{marginTop:4},children:(0,n.jsx)(eF,{style:{fontSize:"12px"},children:new Date(e.system.lastModified).toLocaleString("zh-CN")})})]}),(0,n.jsxs)(ei.Z,{span:8,children:[(0,n.jsx)(eF,{strong:!0,children:"配置版本数："}),(0,n.jsx)("div",{style:{marginTop:4},children:(0,n.jsxs)(eF,{children:[e.system.configVersions," 个"]})})]}),(0,n.jsxs)(ei.Z,{span:16,children:[(0,n.jsx)(eF,{strong:!0,children:"当前配置版本："}),(0,n.jsx)("div",{style:{marginTop:4},children:(0,n.jsx)(eF,{style:{color:"#1890ff"},children:e.system.currentConfigVersion})})]})]})})]})})()})]})};var eB=i(8528),eY=i(3530),eK=i(9170),eG=i(3964),eJ=i(5901),eH=i(4453),eq=i(3788),eW=i(3290),eU=i(5125);let{Title:eX,Text:eQ,Paragraph:e0}=J.Z,{TextArea:e1}=W.Z,{Option:e2}=ea.Z,e5=()=>{var e;let[t,i]=(0,s.useState)([]),[r,a]=(0,s.useState)(!1),[l,o]=(0,s.useState)(!1),[d,c]=(0,s.useState)(!1),[h,x]=(0,s.useState)(!1),[p,g]=(0,s.useState)(!1),[m,u]=(0,s.useState)(null),[f,j]=(0,s.useState)(null),[y]=U.Z.useForm(),[b,Z]=(0,s.useState)(""),v=()=>{a(!0);try{let e=_.getAllVersions();i(e)}catch(e){X.ZP.error("加载版本列表失败")}finally{a(!1)}};(0,s.useEffect)(()=>{v()},[]);let S=async()=>{try{let e=await y.validateFields(),t={name:e.name,description:e.description,tags:e.tags?e.tags.split(",").map(e=>e.trim()):[]};_.createVersion(t),X.ZP.success("版本创建成功！"),o(!1),y.resetFields(),v()}catch(e){console.error("创建版本失败:",e)}},k=e=>{a(!0);try{_.restoreVersion(e)?(X.ZP.success("版本恢复成功！页面将刷新以应用更改。"),setTimeout(()=>window.location.reload(),1500)):X.ZP.error("版本恢复失败")}catch(e){X.ZP.error("恢复版本时发生错误")}finally{a(!1)}},w=e=>{_.deleteVersion(e)?(X.ZP.success("版本删除成功"),v()):X.ZP.error("版本删除失败")},I=e=>{u(e),c(!0)},C=[{title:"版本名称",dataIndex:"name",key:"name",render:(e,t)=>(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(eQ,{strong:t.id===_.getCurrentVersionId(),children:e}),t.id===_.getCurrentVersionId()&&(0,n.jsx)(eB.Z,{color:"green",children:"当前"}),t.isAutoSaved&&(0,n.jsx)(eB.Z,{color:"blue",children:"自动"})]})},{title:"描述",dataIndex:"description",key:"description",ellipsis:!0,render:e=>e||"-"},{title:"标签",dataIndex:"tags",key:"tags",render:e=>(0,n.jsx)(n.Fragment,{children:null==e?void 0:e.map(e=>(0,n.jsx)(eB.Z,{icon:(0,n.jsx)(eK.Z,{}),children:e},e))})},{title:"创建时间",dataIndex:"timestamp",key:"timestamp",render:e=>new Date(e).toLocaleString("zh-CN"),sorter:(e,t)=>e.timestamp-t.timestamp},{title:"操作",key:"action",render:(e,t)=>(0,n.jsxs)(q.Z,{size:"small",children:[(0,n.jsx)(el.Z,{title:"查看详情",children:(0,n.jsx)(H.ZP,{type:"text",icon:(0,n.jsx)(ex.Z,{}),onClick:()=>I(t)})}),(0,n.jsx)(el.Z,{title:"恢复此版本",children:(0,n.jsx)(ee.Z,{title:"确定恢复到此版本吗？",description:"当前配置将被覆盖，建议先创建当前版本的备份。",onConfirm:()=>k(t.id),okText:"确定",cancelText:"取消",children:(0,n.jsx)(H.ZP,{type:"text",icon:(0,n.jsx)(eG.Z,{}),disabled:t.id===_.getCurrentVersionId()})})}),(0,n.jsx)(el.Z,{title:"删除版本",children:(0,n.jsx)(ee.Z,{title:"确定删除此版本吗？",onConfirm:()=>w(t.id),okText:"确定",cancelText:"取消",children:(0,n.jsx)(H.ZP,{type:"text",danger:!0,icon:(0,n.jsx)(eg.Z,{}),disabled:t.id===_.getCurrentVersionId()})})})]})}];return(0,n.jsxs)("div",{style:{padding:24},children:[(0,n.jsxs)(eX,{level:2,children:[(0,n.jsx)(eJ.Z,{})," 配置版本管理"]}),(0,n.jsx)(e0,{children:"管理网站配置的不同版本，支持创建、恢复、比较和导入导出版本。"}),(0,n.jsxs)(et.Z,{gutter:[16,16],style:{marginBottom:24},children:[(0,n.jsx)(ei.Z,{span:6,children:(0,n.jsx)(er.Z,{children:(0,n.jsx)(eT.Z,{title:"总版本数",value:t.length,prefix:(0,n.jsx)(eN.Z,{})})})}),(0,n.jsx)(ei.Z,{span:6,children:(0,n.jsx)(er.Z,{children:(0,n.jsx)(eT.Z,{title:"自动保存版本",value:t.filter(e=>e.isAutoSaved).length,prefix:(0,n.jsx)(eH.Z,{})})})}),(0,n.jsx)(ei.Z,{span:6,children:(0,n.jsx)(er.Z,{children:(0,n.jsx)(eT.Z,{title:"手动创建版本",value:t.filter(e=>!e.isAutoSaved).length,prefix:(0,n.jsx)(e_.Z,{})})})}),(0,n.jsx)(ei.Z,{span:6,children:(0,n.jsx)(er.Z,{children:(0,n.jsx)(eT.Z,{title:"当前版本",value:_.getCurrentVersionId()?"已设置":"未设置",prefix:(0,n.jsx)(eq.Z,{})})})})]}),(0,n.jsx)("div",{style:{marginBottom:16},children:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(H.ZP,{type:"primary",icon:(0,n.jsx)(e_.Z,{}),onClick:()=>o(!0),children:"创建版本"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(eH.Z,{}),onClick:()=>{_.autoSave(),X.ZP.success("自动保存完成"),v()},children:"立即自动保存"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(ez.Z,{}),onClick:()=>{let e=new Blob([_.exportVersions()],{type:"application/json"}),t=URL.createObjectURL(e),i=document.createElement("a");i.href=t,i.download=`config_versions_${new Date().toISOString().split("T")[0]}.json`,document.body.appendChild(i),i.click(),document.body.removeChild(i),URL.revokeObjectURL(t),X.ZP.success("版本数据导出成功")},children:"导出版本"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(eW.Z,{}),onClick:()=>g(!0),children:"导入版本"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(eg.Z,{}),onClick:()=>{let e=_.cleanupAutoSaves(5);X.ZP.success(`清理了 ${e} 个旧的自动保存版本`),v()},children:"清理自动保存"})]})}),(0,n.jsx)(er.Z,{children:(0,n.jsx)(en.Z,{columns:C,dataSource:t,rowKey:"id",loading:r,pagination:{pageSize:10,showSizeChanger:!0,showQuickJumper:!0,showTotal:e=>`共 ${e} 个版本`}})}),(0,n.jsx)(es.Z,{title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(e_.Z,{}),"创建新版本"]}),open:l,onOk:S,onCancel:()=>{o(!1),y.resetFields()},width:600,children:(0,n.jsxs)(U.Z,{form:y,layout:"vertical",children:[(0,n.jsx)(U.Z.Item,{name:"name",label:"版本名称",rules:[{required:!0,message:"请输入版本名称"}],children:(0,n.jsx)(W.Z,{placeholder:"例如: 主页改版 v1.0"})}),(0,n.jsx)(U.Z.Item,{name:"description",label:"版本描述",children:(0,n.jsx)(e1,{rows:3,placeholder:"描述此版本的主要变更内容..."})}),(0,n.jsx)(U.Z.Item,{name:"tags",label:"标签",help:"多个标签用逗号分隔",children:(0,n.jsx)(W.Z,{placeholder:"例如: 主页,样式,功能"})})]})}),(0,n.jsx)(es.Z,{title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(ex.Z,{}),"版本详情"]}),open:d,onCancel:()=>c(!1),footer:[(0,n.jsx)(H.ZP,{onClick:()=>c(!1),children:"关闭"},"close")],width:800,children:m&&(0,n.jsxs)("div",{children:[(0,n.jsxs)(eo.Z,{column:2,bordered:!0,children:[(0,n.jsx)(eo.Z.Item,{label:"版本ID",children:m.id}),(0,n.jsx)(eo.Z.Item,{label:"版本名称",children:m.name}),(0,n.jsx)(eo.Z.Item,{label:"创建时间",children:new Date(m.timestamp).toLocaleString("zh-CN")}),(0,n.jsx)(eo.Z.Item,{label:"版本类型",children:m.isAutoSaved?"自动保存":"手动创建"}),(0,n.jsx)(eo.Z.Item,{label:"描述",span:2,children:m.description||"无描述"}),(0,n.jsx)(eo.Z.Item,{label:"标签",span:2,children:(null===(e=m.tags)||void 0===e?void 0:e.map(e=>(0,n.jsx)(eB.Z,{children:e},e)))||"无标签"})]}),(0,n.jsx)(eY.Z,{children:"配置数据预览"}),(0,n.jsx)("pre",{style:{background:"#f5f5f5",padding:"12px",borderRadius:"4px",fontSize:"12px",maxHeight:"300px",overflow:"auto"},children:JSON.stringify(m.data,null,2)})]})}),(0,n.jsxs)(es.Z,{title:(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(eW.Z,{}),"导入版本数据"]}),open:p,onOk:()=>{if(!b.trim()){X.ZP.error("请输入导入数据");return}_.importVersions(b)?(X.ZP.success("版本数据导入成功"),g(!1),Z(""),v()):X.ZP.error("导入失败，请检查数据格式")},onCancel:()=>{g(!1),Z("")},width:800,children:[(0,n.jsx)(eA.Z,{message:"导入说明",description:"支持选择JSON文件或直接粘贴从导出功能生成的数据。导入将覆盖现有的版本数据，请谨慎操作。",type:"warning",style:{marginBottom:16}}),(0,n.jsxs)("div",{style:{marginBottom:16},children:[(0,n.jsx)(eQ,{strong:!0,children:"选择文件："}),(0,n.jsxs)("div",{style:{marginTop:8,padding:"16px",border:"2px dashed #d9d9d9",borderRadius:"6px",textAlign:"center",background:"#fafafa"},children:[(0,n.jsx)("input",{type:"file",accept:".json",onChange:e=>{var t;let i=null===(t=e.target.files)||void 0===t?void 0:t[0];if(!i)return;if(!i.name.endsWith(".json")){X.ZP.error("请选择 JSON 格式的文件");return}let r=new FileReader;r.onload=e=>{var t;let i=null===(t=e.target)||void 0===t?void 0:t.result;i&&(Z(i),X.ZP.success("文件读取成功，请检查数据后点击导入"))},r.onerror=()=>{X.ZP.error("文件读取失败")},r.readAsText(i),e.target.value=""},style:{display:"none"},id:"version-file-input"}),(0,n.jsx)("label",{htmlFor:"version-file-input",style:{cursor:"pointer"},children:(0,n.jsxs)("div",{children:[(0,n.jsx)(eU.Z,{style:{fontSize:"24px",color:"#1890ff",marginBottom:"8px"}}),(0,n.jsx)("div",{style:{color:"#666"},children:"点击选择 JSON 文件"}),(0,n.jsx)("div",{style:{fontSize:"12px",color:"#999",marginTop:"4px"},children:"支持从版本管理导出的 .json 文件"})]})})]})]}),(0,n.jsx)(eY.Z,{children:"或"}),(0,n.jsxs)("div",{children:[(0,n.jsx)(eQ,{strong:!0,children:"直接粘贴 JSON 数据："}),(0,n.jsx)(e1,{rows:12,value:b,onChange:e=>Z(e.target.value),placeholder:"请粘贴版本数据的 JSON 格式...",style:{fontFamily:"monospace",fontSize:"12px",marginTop:8}})]}),b&&(0,n.jsxs)("div",{style:{marginTop:16},children:[(0,n.jsx)(eQ,{strong:!0,children:"数据预览："}),(0,n.jsx)("div",{style:{marginTop:8,background:"#f5f5f5",padding:"12px",borderRadius:"6px",maxHeight:"150px",overflow:"auto"},children:(0,n.jsx)("pre",{style:{margin:0,fontSize:"11px",color:"#666"},children:(()=>{try{var e,t;let i=JSON.parse(b),r={版本数量:(null===(e=i.versions)||void 0===e?void 0:e.length)||0,最大版本数:i.maxVersions||"N/A",当前版本:i.currentVersionId||"无",示例版本:(null===(t=i.versions)||void 0===t?void 0:t[0])?{名称:i.versions[0].name,创建时间:new Date(i.versions[0].timestamp).toLocaleString("zh-CN"),是否自动保存:i.versions[0].isAutoSaved||!1}:"无"};return JSON.stringify(r,null,2)}catch{return"无效的JSON格式"}})()})})]})]})]})};var e4=i(4806),e6=i(6905),e8=i(5488),e3=i(6118),e9=i(4799),e7=i(8640),te=i(7641),tt=i(2777),ti=i(4677),tr=i(3119),tn=i(644),ts=i(360),ta=i(3809),tl=i(1926),to=i(8094),td=i(9906),tc=i(784),th=i(8951),tx=i(5587),tp=i(3626),tg=i(3332),tm=i(6375);let{Title:tu,Paragraph:tf,Text:tj,Link:ty}=J.Z,{Option:tb}=ea.Z,{Step:tZ}=e4.Z,{TabPane:tv}=e6.Z,{Panel:tS}=e8.Z,tk=()=>{let[e,t]=(0,s.useState)(!1),[i,r]=(0,s.useState)(!1),[a,l]=(0,s.useState)(!1),[o,d]=(0,s.useState)(!1),[c,h]=(0,s.useState)(50),[x,p]=(0,s.useState)(4),[g,m]=(0,s.useState)(1),[u]=U.Z.useForm(),f=[{title:"姓名",dataIndex:"name",key:"name"},{title:"年龄",dataIndex:"age",key:"age"},{title:"地址",dataIndex:"address",key:"address"},{title:"状态",dataIndex:"status",key:"status",render:e=>(0,n.jsx)(e3.Z,{status:"active"===e?"success":"default",text:"active"===e?"活跃":"非活跃"})}],j=(0,n.jsxs)("div",{children:[(0,n.jsx)("p",{children:"这是一个 Popover 组件的内容"}),(0,n.jsx)("p",{children:"可以包含任意的 React 元素"})]});return(0,n.jsxs)("div",{style:{padding:24},children:[(0,n.jsxs)(tu,{level:2,children:[(0,n.jsx)(td.Z,{})," Ant Design 组件展示面板"]}),(0,n.jsx)(tf,{children:"这个面板展示了 Ant Design 在本项目中的集成效果，包含了常用组件的使用示例。 所有组件都支持主题切换，并与项目的整体设计保持一致。"}),(0,n.jsxs)(e6.Z,{defaultActiveKey:"1",children:[(0,n.jsxs)(tv,{tab:"基础组件",children:[(0,n.jsxs)(eY.Z,{orientation:"left",children:[(0,n.jsx)(tc.Z,{})," 按钮组件"]}),(0,n.jsxs)(q.Z,{wrap:!0,style:{marginBottom:16},children:[(0,n.jsx)(H.ZP,{type:"primary",children:"主要按钮"}),(0,n.jsx)(H.ZP,{children:"默认按钮"}),(0,n.jsx)(H.ZP,{type:"dashed",children:"虚线按钮"}),(0,n.jsx)(H.ZP,{type:"text",children:"文本按钮"}),(0,n.jsx)(H.ZP,{type:"link",children:"链接按钮"}),(0,n.jsx)(H.ZP,{type:"primary",danger:!0,children:"危险按钮"}),(0,n.jsx)(H.ZP,{type:"primary",loading:e,onClick:()=>t(!e),children:e?"加载中":"切换加载"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(th.Z,{}),children:"图标按钮"})]}),(0,n.jsx)(eY.Z,{orientation:"left",children:"反馈组件"}),(0,n.jsxs)(q.Z,{direction:"vertical",style:{width:"100%",marginBottom:16},children:[(0,n.jsx)(eA.Z,{message:"信息提示",type:"info",showIcon:!0}),(0,n.jsx)(eA.Z,{message:"成功提示",type:"success",showIcon:!0,closable:!0}),(0,n.jsx)(eA.Z,{message:"警告提示",type:"warning",showIcon:!0}),(0,n.jsx)(eA.Z,{message:"错误提示",type:"error",showIcon:!0}),(0,n.jsxs)(q.Z,{wrap:!0,children:[(0,n.jsx)(H.ZP,{onClick:()=>{e9.ZP.success({message:"操作成功",description:"这是一个成功的通知消息示例，展示了 Ant Design 的 notification 组件功能。",placement:"topRight",duration:4})},children:"显示通知"}),(0,n.jsx)(H.ZP,{onClick:()=>{X.ZP.success("这是一个成功的消息提示")},children:"成功消息"}),(0,n.jsx)(H.ZP,{onClick:()=>{X.ZP.warning("这是一个警告消息")},children:"警告消息"}),(0,n.jsx)(H.ZP,{onClick:()=>{X.ZP.error("这是一个错误消息")},children:"错误消息"}),(0,n.jsx)(H.ZP,{onClick:()=>r(!0),children:"打开模态框"}),(0,n.jsx)(H.ZP,{onClick:()=>l(!0),children:"打开抽屉"})]})]}),(0,n.jsx)(eY.Z,{orientation:"left",children:"数据展示"}),(0,n.jsxs)(et.Z,{gutter:[16,16],style:{marginBottom:16},children:[(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsx)(er.Z,{title:"进度和评分",size:"small",children:(0,n.jsxs)(q.Z,{direction:"vertical",style:{width:"100%"},children:[(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"进度条:"}),(0,n.jsx)(e7.Z,{percent:75,status:"active"})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"环形进度:"}),(0,n.jsx)(e7.Z,{type:"circle",percent:60,width:60})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"评分:"}),(0,n.jsx)(te.Z,{value:x,onChange:p}),(0,n.jsxs)(tj,{style:{marginLeft:8},children:[x," 星"]})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"标签:"}),(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(eB.Z,{color:"blue",children:"React"}),(0,n.jsx)(eB.Z,{color:"green",children:"TypeScript"}),(0,n.jsx)(eB.Z,{color:"orange",children:"Ant Design"}),(0,n.jsx)(eB.Z,{color:"purple",children:"Emotion"})]})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"徽章:"}),(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(e3.Z,{count:5,children:(0,n.jsx)(ed.Z,{shape:"square",icon:(0,n.jsx)(tx.Z,{})})}),(0,n.jsx)(e3.Z,{dot:!0,children:(0,n.jsx)(ed.Z,{shape:"square",icon:(0,n.jsx)(tx.Z,{})})}),(0,n.jsx)(e3.Z,{count:99,overflowCount:10,children:(0,n.jsx)(ed.Z,{shape:"square",icon:(0,n.jsx)(tx.Z,{})})})]})]})]})})}),(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsxs)(er.Z,{title:"步骤条",size:"small",children:[(0,n.jsxs)(e4.Z,{current:g,size:"small",style:{marginBottom:16},children:[(0,n.jsx)(tZ,{title:"已完成",description:"第一步完成"}),(0,n.jsx)(tZ,{title:"进行中",description:"当前步骤"}),(0,n.jsx)(tZ,{title:"等待中",description:"待执行"})]}),(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(H.ZP,{size:"small",onClick:()=>m(Math.max(0,g-1)),children:"上一步"}),(0,n.jsx)(H.ZP,{type:"primary",size:"small",onClick:()=>m(Math.min(2,g+1)),children:"下一步"})]})]})})]})]},"1"),(0,n.jsx)(tv,{tab:"表单组件",children:(0,n.jsxs)(et.Z,{gutter:[16,16],children:[(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsx)(er.Z,{title:"表单控件",size:"small",children:(0,n.jsxs)(U.Z,{form:u,onFinish:e=>{console.log("表单提交:",e),X.ZP.success("表单提交成功！数据已记录到控制台")},layout:"vertical",children:[(0,n.jsx)(U.Z.Item,{name:"username",label:"用户名",rules:[{required:!0,message:"请输入用户名"}],children:(0,n.jsx)(W.Z,{prefix:(0,n.jsx)(tx.Z,{}),placeholder:"请输入用户名"})}),(0,n.jsx)(U.Z.Item,{name:"email",label:"邮箱",children:(0,n.jsx)(W.Z,{type:"email",placeholder:"请输入邮箱"})}),(0,n.jsx)(U.Z.Item,{name:"city",label:"城市",children:(0,n.jsxs)(ea.Z,{placeholder:"请选择城市",children:[(0,n.jsx)(tb,{value:"beijing",children:"北京"}),(0,n.jsx)(tb,{value:"shanghai",children:"上海"}),(0,n.jsx)(tb,{value:"guangzhou",children:"广州"}),(0,n.jsx)(tb,{value:"shenzhen",children:"深圳"})]})}),(0,n.jsx)(U.Z.Item,{name:"date",label:"日期",children:(0,n.jsx)(tt.Z,{style:{width:"100%"}})}),(0,n.jsx)(U.Z.Item,{name:"time",label:"时间",children:(0,n.jsx)(ti.Z,{style:{width:"100%"}})}),(0,n.jsx)(U.Z.Item,{children:(0,n.jsx)(H.ZP,{type:"primary",htmlType:"submit",children:"提交表单"})})]})})}),(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsx)(er.Z,{title:"其他控件",size:"small",children:(0,n.jsxs)(q.Z,{direction:"vertical",style:{width:"100%"},children:[(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"开关:"}),(0,n.jsx)(tr.Z,{checked:o,onChange:d,style:{marginLeft:8}}),(0,n.jsx)(tj,{style:{marginLeft:8},children:o?"开启":"关闭"})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"滑动条:"}),(0,n.jsx)(ew.Z,{value:c,onChange:h,style:{margin:"0 8px"}}),(0,n.jsxs)(tj,{children:["值: ",c]})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"复选框:"}),(0,n.jsxs)(tn.Z.Group,{style:{marginLeft:8},children:[(0,n.jsx)(tn.Z,{value:"option1",children:"选项1"}),(0,n.jsx)(tn.Z,{value:"option2",children:"选项2"}),(0,n.jsx)(tn.Z,{value:"option3",children:"选项3"})]})]}),(0,n.jsxs)("div",{children:[(0,n.jsx)(tj,{children:"单选框:"}),(0,n.jsxs)(ts.ZP.Group,{style:{marginLeft:8},children:[(0,n.jsx)(ts.ZP,{value:"a",children:"选项A"}),(0,n.jsx)(ts.ZP,{value:"b",children:"选项B"}),(0,n.jsx)(ts.ZP,{value:"c",children:"选项C"})]})]})]})})})]})},"2"),(0,n.jsxs)(tv,{tab:"数据展示",children:[(0,n.jsxs)(et.Z,{gutter:[16,16],children:[(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsx)(er.Z,{title:"表格组件",size:"small",children:(0,n.jsx)(en.Z,{dataSource:[{key:"1",name:"张三",age:32,address:"北京市朝阳区",status:"active"},{key:"2",name:"李四",age:28,address:"上海市浦东区",status:"inactive"},{key:"3",name:"王五",age:35,address:"广州市天河区",status:"active"}],columns:f,pagination:{pageSize:5},size:"small"})})}),(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsx)(er.Z,{title:"列表组件",size:"small",children:(0,n.jsx)(Q.Z,{itemLayout:"horizontal",dataSource:[{title:"Ant Design 组件库",description:"企业级 UI 设计语言和 React 组件库",avatar:"\uD83C\uDFA8"},{title:"React 19",description:"用于构建用户界面的 JavaScript 库",avatar:"⚛️"},{title:"TypeScript",description:"JavaScript 的强类型超集",avatar:"\uD83D\uDCD8"},{title:"Emotion.js",description:"高性能的 CSS-in-JS 库",avatar:"\uD83D\uDC85"}],size:"small",renderItem:e=>(0,n.jsx)(Q.Z.Item,{actions:[(0,n.jsx)(H.ZP,{type:"link",children:"编辑"},"edit"),(0,n.jsx)(H.ZP,{type:"link",children:"更多"},"more")],children:(0,n.jsx)(Q.Z.Item.Meta,{avatar:(0,n.jsx)(ed.Z,{style:{backgroundColor:"#1890ff"},children:e.avatar}),title:e.title,description:e.description})})})})})]}),(0,n.jsx)(eY.Z,{}),(0,n.jsx)(er.Z,{title:"折叠面板",size:"small",children:(0,n.jsxs)(e8.Z,{children:[(0,n.jsxs)(tS,{header:"面板1 - 基础信息",children:[(0,n.jsx)("p",{children:"这是第一个面板的内容。可以包含任意的React组件。"}),(0,n.jsx)(H.ZP,{type:"primary",size:"small",children:"操作按钮"})]},"1"),(0,n.jsxs)(tS,{header:"面板2 - 高级设置",children:[(0,n.jsx)("p",{children:"这是第二个面板的内容。支持嵌套组件和交互功能。"}),(0,n.jsxs)(q.Z,{children:[(0,n.jsx)(H.ZP,{size:"small",children:"确定"}),(0,n.jsx)(H.ZP,{size:"small",children:"取消"})]})]},"2"),(0,n.jsx)(tS,{header:"面板3 - 帮助信息",children:(0,n.jsx)("p",{children:"这是第三个面板的内容。可以用来展示帮助文档或说明。"})},"3")]})})]},"3"),(0,n.jsxs)(tv,{tab:"导航组件",children:[(0,n.jsx)(er.Z,{title:"面包屑导航",size:"small",style:{marginBottom:16},children:(0,n.jsxs)(ta.Z,{children:[(0,n.jsx)(ta.Z.Item,{href:"",children:(0,n.jsx)(tp.Z,{})}),(0,n.jsxs)(ta.Z.Item,{href:"",children:[(0,n.jsx)(tx.Z,{}),(0,n.jsx)("span",{children:"用户管理"})]}),(0,n.jsx)(ta.Z.Item,{children:"用户列表"}),(0,n.jsx)(ta.Z.Item,{children:"用户详情"})]})}),(0,n.jsx)(er.Z,{title:"交互组件",size:"small",children:(0,n.jsxs)(q.Z,{wrap:!0,children:[(0,n.jsx)(el.Z,{title:"这是一个提示信息",children:(0,n.jsx)(H.ZP,{children:"悬停提示"})}),(0,n.jsx)(tl.Z,{content:j,title:"弹出框标题",children:(0,n.jsx)(H.ZP,{children:"点击弹出"})}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(tg.Z,{}),children:"点赞"}),(0,n.jsx)(H.ZP,{icon:(0,n.jsx)(tm.Z,{}),type:"primary",danger:!0,children:"收藏"})]})})]},"4")]}),(0,n.jsxs)(es.Z,{title:"模态框示例",open:i,onOk:()=>r(!1),onCancel:()=>r(!1),width:500,children:[(0,n.jsx)("p",{children:"这是一个模态框的内容示例。"}),(0,n.jsx)("p",{children:"模态框支持各种配置选项："}),(0,n.jsxs)("ul",{children:[(0,n.jsx)("li",{children:"自定义宽度和高度"}),(0,n.jsx)("li",{children:"确定和取消按钮"}),(0,n.jsx)("li",{children:"遮罩层点击关闭"}),(0,n.jsx)("li",{children:"键盘ESC关闭"})]}),(0,n.jsx)(eA.Z,{message:"提示",description:"模态框内可以嵌套任意组件",type:"info",showIcon:!0})]}),(0,n.jsx)(to.Z,{title:"抽屉组件示例",placement:"right",onClose:()=>l(!1),open:a,width:400,children:(0,n.jsxs)("div",{children:[(0,n.jsx)(tu,{level:4,children:"抽屉内容"}),(0,n.jsx)(tf,{children:"抽屉组件可以从四个方向滑出，常用于展示详细信息或者侧边栏导航。"}),(0,n.jsx)(eY.Z,{}),(0,n.jsxs)(q.Z,{direction:"vertical",style:{width:"100%"},children:[(0,n.jsx)(H.ZP,{type:"primary",block:!0,children:"主要操作"}),(0,n.jsx)(H.ZP,{block:!0,children:"次要操作"}),(0,n.jsx)(H.ZP,{danger:!0,block:!0,onClick:()=>l(!1),children:"关闭抽屉"})]}),(0,n.jsx)(eY.Z,{}),(0,n.jsx)(eA.Z,{message:"功能说明",description:"抽屉组件适用于需要临时显示大量信息的场景",type:"success",showIcon:!0})]})})]})},tw=e=>{switch(console.log("AdminPanel",e.config),e.config){case G.THEME_ADMIN_PANEL:return(0,n.jsx)(eP,{});case G.SITE_ADMIN_PANEL:return(0,n.jsx)(eM,{});case G.LINKS_ADMIN_PANEL:return(0,n.jsx)(ek,{});case G.VERSION_ADMIN_PANEL:return(0,n.jsx)(e5,{});case G.ANTD_SHOWCASE_PANEL:return(0,n.jsx)(tk,{});default:return(0,n.jsx)("div",{children:"未知面板"})}},tI=[{name:"链接配置面板",type:"default",value:G.LINKS_ADMIN_PANEL},{name:"主题配置面板",type:"primary",value:G.THEME_ADMIN_PANEL},{name:"网站配置面板",type:"dashed",value:G.SITE_ADMIN_PANEL},{name:"配置版本管理",type:"dashed",value:G.VERSION_ADMIN_PANEL},{name:"Ant Design 展示",type:"link",value:G.ANTD_SHOWCASE_PANEL}],tC=e=>{switch(e){case G.LINKS_ADMIN_PANEL:return(0,n.jsx)(em.Z,{});case G.THEME_ADMIN_PANEL:return(0,n.jsx)(eI.Z,{});case G.SITE_ADMIN_PANEL:return(0,n.jsx)(eD.Z,{});case G.ANTD_SHOWCASE_PANEL:return(0,n.jsx)(td.Z,{});case G.VERSION_ADMIN_PANEL:return(0,n.jsx)(eJ.Z,{});default:return null}},tE=e=>{switch(e){case G.LINKS_ADMIN_PANEL:return"管理链接分类和搜索引擎配置";case G.THEME_ADMIN_PANEL:return"自定义主题风格和外观设置";case G.SITE_ADMIN_PANEL:return"网站基本信息和SEO配置";case G.ANTD_SHOWCASE_PANEL:return"查看Ant Design组件展示";case G.VERSION_ADMIN_PANEL:return"管理配置版本，支持创建、恢复和比较";default:return""}},tP=e=>{let{visibleAdmin:t,setIsShowAdmin:i,setVisibleAdmin:r,setToConfig:s,isShowAdmin:a}=e,l=e=>()=>{switch(console.log("toAdmin",e),e.value){case G.LINKS_ADMIN_PANEL:s(G.LINKS_ADMIN_PANEL);break;case G.THEME_ADMIN_PANEL:s(G.THEME_ADMIN_PANEL);break;case G.SITE_ADMIN_PANEL:s(G.SITE_ADMIN_PANEL);break;case G.ANTD_SHOWCASE_PANEL:s(G.ANTD_SHOWCASE_PANEL);break;case G.VERSION_ADMIN_PANEL:s(G.VERSION_ADMIN_PANEL);break;default:r(!0)}r(!0),i(!1)};return(0,n.jsx)(n.Fragment,{children:(0,n.jsx)(es.Z,{title:"选择管理面板",footer:[(0,n.jsx)(H.ZP,{style:{display:t?"":"none"},onClick:()=>{i(!1),r(!1)},children:"退出面板"},"back")],open:a,onCancel:()=>i(!1),width:800,children:(0,n.jsx)(et.Z,{gutter:[16,16],children:tI.map((e,t)=>(0,n.jsx)(ei.Z,{span:12,children:(0,n.jsx)(er.Z,{hoverable:!0,onClick:l(e),style:{height:"120px",cursor:"pointer"},children:(0,n.jsxs)(q.Z,{direction:"vertical",align:"center",style:{width:"100%"},children:[(0,n.jsx)("div",{style:{fontSize:"24px",color:"#1890ff"},children:tC(e.value)}),(0,n.jsxs)("div",{style:{textAlign:"center"},children:[(0,n.jsx)("div",{style:{fontWeight:"bold",marginBottom:"4px"},children:e.name}),(0,n.jsx)("div",{style:{fontSize:"12px",color:"#666"},children:tE(e.value)})]})]})})},t))})})})};var tT=i(7374);let tA=(0,tT.F4)`
  from {
    opacity: 0;
    transform: scale(0.8);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
`,tD=(0,tT.F4)`
  0%, 100% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.1);
    opacity: 0.8;
  }
`,t_=o.Z.div`
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: ${e=>{var t,i;return(null===(t=e.theme)||void 0===t?void 0:t.id)==="custom"&&(null===(i=e.theme)||void 0===i?void 0:i.name)==="暗黑主题"?"rgba(0, 0, 0, 0.9)":"rgba(255, 255, 255, 0.95)"}};
  backdrop-filter: blur(20px);
  -webkit-backdrop-filter: blur(20px);
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  animation: ${tA} 0.5s ease-out;
`,tN=o.Z.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2rem;
`,tz=o.Z.div`
  width: 60px;
  height: 60px;
  border: 4px solid ${e=>{var t,i;return(null===(t=e.theme)||void 0===t?void 0:t.id)==="custom"&&(null===(i=e.theme)||void 0===i?void 0:i.name)==="暗黑主题"?"rgba(255, 255, 255, 0.1)":"rgba(0, 0, 0, 0.1)"}};
  border-top: 4px solid #4a90e2;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  
  @keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
  }
`,tO=o.Z.div`
  color: ${e=>{var t,i;return(null===(t=e.theme)||void 0===t?void 0:t.id)==="custom"&&(null===(i=e.theme)||void 0===i?void 0:i.name)==="暗黑主题"?"#ffffff":"#2c3e50"}};
  font-size: 1.1rem;
  font-weight: 500;
  animation: ${tD} 2s ease-in-out infinite;
  text-align: center;
  max-width: 300px;
`,t$=o.Z.div`
  font-size: 3rem;
  animation: ${tD} 1.5s ease-in-out infinite;
  margin-bottom: 1rem;
`,tL=e=>{let{theme:t,text:i="正在加载精彩内容..."}=e;return(0,n.jsx)(t_,{theme:t,children:(0,n.jsxs)(tN,{children:[(0,n.jsx)(t$,{children:"\uD83D\uDE80"}),(0,n.jsx)(tz,{theme:t}),(0,n.jsx)(tO,{theme:t,children:i})]})})},tV=o.Z.button`
  opacity: 0.5; /* 默认透明度 */
  background-color: transparent; /* 默认背景颜色设置为透明 */
  border: none; /* 去掉边框 */
  color: white; /* 默认字体颜色为蓝色 */
  transition: opacity 0.3s ease; /* 过渡效果 */
  cursor: pointer; /* 显示鼠标小手 */
  &:focus {
    outline: none; /* 去掉焦点时的边框 */
  }

  &:hover {
    opacity: 1; /* 鼠标悬停时的透明度 */
    background-color: transparent; /* 鼠标悬停时背景颜色仍为透明 */
  }
`,tF=o.Z.header`
  text-align: center;
  margin-bottom: 2rem;
  position: relative;
  padding: 2rem 0 1rem;
  
  /* 添加纻丽的动画效果 */
  animation: fadeInDown 0.8s ease-out;
  
  @keyframes fadeInDown {
    from {
      opacity: 0;
      transform: translateY(-30px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
`,tR=o.Z.h1`
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#2c3e50"};
  font-size: 2.8rem;
  margin-bottom: 0.5rem;
  font-weight: 800;
  text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.15);
  letter-spacing: -0.02em;
  background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"linear-gradient(135deg, #ffffff 0%, #f0f0f0 100%)":"linear-gradient(135deg, #2c3e50 0%, #4a90e2 50%, #2c3e50 100%)"};
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  background-clip: text;
  
  /* 加入一些活力 */
  transition: all 0.3s ease;
  
  &:hover {
    transform: scale(1.02);
    filter: brightness(1.1);
  }
  
  @media (max-width: 768px) {
    font-size: 2.2rem;
    letter-spacing: -0.01em;
  }
  
  @media (max-width: 480px) {
    font-size: 1.8rem;
  }
`,tM=o.Z.main`
  max-width: 1200px;
  margin: 0 auto;
  background: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"rgba(0, 0, 0, 0.4)":"rgba(255, 255, 255, 0.65)"};
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#2c3e50"};
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-radius: 20px;
  padding: 24px;
  box-shadow: 
    0 12px 40px 0 rgba(31, 38, 135, 0.2),
    0 2px 16px 0 rgba(0, 0, 0, 0.05),
    inset 0 1px 0 rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.1);
  
  /* 动画效果 */
  animation: fadeInUp 0.8s ease-out 0.2s both;
  
  @keyframes fadeInUp {
    from {
      opacity: 0;
      transform: translateY(40px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  /* 响应式设计 */
  @media (max-width: 768px) {
    margin: 0 1rem;
    padding: 20px;
    border-radius: 16px;
  }
  
  @media (max-width: 480px) {
    margin: 0 0.5rem;
    padding: 16px;
    border-radius: 12px;
  }
`,tB=o.Z.footer`
  text-align: center;
  padding: 24px 20px;
  color: ${e=>"custom"===e.theme.id&&"暗黑主题"===e.theme.name?"#ffffff":"#2c3e50"};
  font-size: 14px;
  opacity: 0.8;
  margin-top: 2.5rem;
  
  /* 动画效果 */
  animation: fadeIn 1s ease-out 0.4s both;
  
  @keyframes fadeIn {
    from {
      opacity: 0;
    }
    to {
      opacity: 0.8;
    }
  }

  @media (max-width: 768px) {
    padding: 20px 15px;
    font-size: 13px;
    margin-top: 2rem;
  }
  
  @media (max-width: 480px) {
    padding: 16px 12px;
    font-size: 12px;
    margin-top: 1.5rem;
  }
`,{Text:tY}=J.Z,tK=e=>{let{cb:t}=e,i=C.getConfig(),[r,a]=(0,s.useState)(T.getAllCategories()),l=T.getAllSearchEngines(),[o,d]=(0,s.useState)(""),[c,h]=(0,s.useState)(!0);(0,s.useMemo)(()=>{let e=z("turnip_link_categories");console.log("localCategories",e),a(e),setTimeout(()=>h(!1),100)},[]),(0,s.useEffect)(()=>{let e=()=>{let e=new Date().getHours();e<6?d("\uD83C\uDF19 夜深了，注意休息"):e<11?d("\uD83C\uDF05 早上好，新的一天开始了"):e<14?d("☀️ 午安，享受美好时光"):e<18?d("\uD83C\uDF24️ 下午好，继续加油"):e<22?d("\uD83C\uDF06 晚上好，放松一下吧"):d("\uD83C\uDF03 夜晚时光，愿你安好")};e();let t=setInterval(e,6e4);return()=>clearInterval(t)},[]);let x=D.getConfig(),p=r.reduce((e,t)=>{var i;return e+((null===(i=t.links)||void 0===i?void 0:i.length)||0)},0);return c?(0,n.jsx)(tL,{theme:i.default,text:"正在初始化精彩内容..."}):(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(tF,{children:(0,n.jsx)("div",{style:{position:"relative",width:"100%"},children:(0,n.jsxs)("div",{style:{display:"flex",flexDirection:"column",alignItems:"center",gap:"0.5rem"},children:[(0,n.jsx)(tR,{children:x.title}),(0,n.jsxs)(q.Z,{direction:"vertical",align:"center",style:{marginTop:"0.5rem",textAlign:"center"},children:[(0,n.jsx)(tY,{style:{fontSize:"1rem",opacity:.9,color:"custom"===i.default.id&&"暗黑主题"===i.default.name?"#ffffff":"#2c3e50"},children:o}),(0,n.jsxs)(q.Z,{size:"large",children:[(0,n.jsx)(q.Z,{children:(0,n.jsxs)(tY,{style:{fontSize:"0.875rem",opacity:.7,color:"custom"===i.default.id&&"暗黑主题"===i.default.name?"#ffffff":"#666"},children:["\uD83D\uDCC1 ",r.length," 个分类"]})}),(0,n.jsx)(q.Z,{children:(0,n.jsxs)(tY,{style:{fontSize:"0.875rem",opacity:.7,color:"custom"===i.default.id&&"暗黑主题"===i.default.name?"#ffffff":"#666"},children:["\uD83D\uDD17 ",p," 个链接"]})})]})]})]})})}),(0,n.jsxs)(tM,{children:[(0,n.jsx)(m,{searchEngines:l}),(0,n.jsx)(v,{categories:r})]}),(0,n.jsx)(B,{themeConfig:i,onSelect:t}),(0,n.jsx)(tB,{children:(0,n.jsxs)(q.Z,{direction:"vertical",align:"center",style:{width:"100%"},children:[(0,n.jsx)(tY,{style:{color:"custom"===i.default.id&&"暗黑主题"===i.default.name?"#ffffff":"#2c3e50",opacity:.8},children:x.copyright.text}),x.author&&(0,n.jsxs)(tY,{style:{fontSize:"12px",color:"custom"===i.default.id&&"暗黑主题"===i.default.name?"#ffffff":"#666",opacity:.6},children:["Made with ❤️ by ",x.author]})]})})]})},tG="turnip-theme-active",tJ=e=>{let[t,i]=(0,s.useState)(()=>{try{let t=localStorage.getItem(tG);return t?JSON.parse(t):e.default}catch(t){return console.warn("Failed to parse saved theme:",t),e.default}});return(0,s.useEffect)(()=>{try{localStorage.setItem(tG,JSON.stringify(t))}catch(e){console.warn("Failed to save theme:",e)}},[t]),[t,i]};var tH=i(3482),tq=i(9957),tW=i(2460);i(9134);let tU=document.getElementById("root");tU&&a.createRoot(tU).render((0,n.jsx)(s.StrictMode,{children:(0,n.jsx)(()=>{let[e,t]=(0,s.useState)(!1),[i,r]=(0,s.useState)(G.LINKS_ADMIN_PANEL),[a,o]=(0,s.useState)(!1),[d,c]=tJ(C.getConfig()),h={algorithm:"custom"===d.id&&"暗黑主题"===d.name?tH.Z.darkAlgorithm:tH.Z.defaultAlgorithm,token:{colorPrimary:"#4a90e2",borderRadius:8,colorBgContainer:"custom"===d.id&&"暗黑主题"===d.name?"rgba(0, 0, 0, 0.6)":"rgba(255, 255, 255, 0.8)"},components:{Modal:{contentBg:"custom"===d.id&&"暗黑主题"===d.name?"rgba(0, 0, 0, 0.8)":"rgba(255, 255, 255, 0.95)"},Button:{borderRadius:6},Input:{borderRadius:6}}};return(0,n.jsx)(tq.ZP,{theme:h,children:(0,n.jsx)(tW.Z,{children:(0,n.jsx)(l.a,{theme:d,children:(0,n.jsxs)(S,{theme:d,children:[(0,n.jsx)(K,{}),(0,n.jsx)(tV,{onClick:()=>o(!0),children:"管理面板"}),e?(0,n.jsx)(tw,{config:i}):(0,n.jsx)(tK,{cb:c}),(0,n.jsx)(tP,{setVisibleAdmin:t,visibleAdmin:e,setToConfig:r,setIsShowAdmin:o,isShowAdmin:a})]})})})})},{})}))}},t={};function i(r){var n=t[r];if(void 0!==n)return n.exports;var s=t[r]={exports:{}};return e[r].call(s.exports,s,s.exports,i),s.exports}i.m=e,i.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return i.d(t,{a:t}),t},(()=>{var e,t=Object.getPrototypeOf?function(e){return Object.getPrototypeOf(e)}:function(e){return e.__proto__};i.t=function(r,n){if(1&n&&(r=this(r)),8&n||"object"==typeof r&&r&&(4&n&&r.__esModule||16&n&&"function"==typeof r.then))return r;var s=Object.create(null);i.r(s);var a={};e=e||[null,t({}),t([]),t(t)];for(var l=2&n&&r;"object"==typeof l&&!~e.indexOf(l);l=t(l))Object.getOwnPropertyNames(l).forEach(function(e){a[e]=function(){return r[e]}});return a.default=function(){return r},i.d(s,a),s}})(),i.d=function(e,t){for(var r in t)i.o(t,r)&&!i.o(e,r)&&Object.defineProperty(e,r,{enumerable:!0,get:t[r]})},i.g=function(){if("object"==typeof globalThis)return globalThis;try{return this||Function("return this")()}catch(e){if("object"==typeof window)return window}}(),i.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},i.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},(()=>{var e=[];i.O=function(t,r,n,s){if(r){s=s||0;for(var a=e.length;a>0&&e[a-1][2]>s;a--)e[a]=e[a-1];e[a]=[r,n,s];return}for(var l=1/0,a=0;a<e.length;a++){for(var r=e[a][0],n=e[a][1],s=e[a][2],o=!0,d=0;d<r.length;d++)(!1&s||l>=s)&&Object.keys(i.O).every(function(e){return i.O[e](r[d])})?r.splice(d--,1):(o=!1,s<l&&(l=s));if(o){e.splice(a--,1);var c=n();void 0!==c&&(t=c)}}return t}})(),i.rv=function(){return"1.2.2"},(()=>{var e={980:0};i.O.j=function(t){return 0===e[t]};var t=function(t,r){var n,s,a=r[0],l=r[1],o=r[2],d=0;if(a.some(function(t){return 0!==e[t]})){for(n in l)i.o(l,n)&&(i.m[n]=l[n]);if(o)var c=o(i)}for(t&&t(r);d<a.length;d++)s=a[d],i.o(e,s)&&e[s]&&e[s][0](),e[s]=0;return i.O(c)},r=self.webpackChunkrs_react_app=self.webpackChunkrs_react_app||[];r.forEach(t.bind(null,0)),r.push=t.bind(null,r.push.bind(r))})(),i.ruid="bundler=rspack@1.2.2";var r=i.O(void 0,["361","647"],function(){return i(1600)});r=i.O(r)})();